/**
 * FlyoutQueryEditor - Embedded SQL editor for the flyout panel
 * 
 * A compact SQL editor with execution capabilities that can be
 * embedded within the QueryPanel flyout for testing queries inline.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Editor from '@monaco-editor/react';
import { 
  Play, X, Loader2, Check, AlertCircle, ChevronDown, ChevronRight,
  Copy, Database, Clock, RotateCcw, Maximize2, Minimize2, WifiOff, Snowflake
} from 'lucide-react';
import { useQuery, useConnection } from '../hooks/useSnowflake';

// Parse SQL errors into friendly messages
function parseSqlError(error) {
  const errorStr = String(error);
  
  // Extract line number if present
  const lineMatch = errorStr.match(/line\s+(\d+)/i) || errorStr.match(/at\s+position.*?line\s+(\d+)/i);
  const line = lineMatch ? parseInt(lineMatch[1], 10) : null;
  
  // Common typo patterns
  const typoPatterns = [
    { pattern: /syntax error.*?['"]?SELEC['"]?/i, suggestion: 'Did you mean SELECT?' },
    { pattern: /syntax error.*?['"]?FORM['"]?/i, suggestion: 'Did you mean FROM?' },
    { pattern: /syntax error.*?['"]?WEHERE['"]?/i, suggestion: 'Did you mean WHERE?' },
    { pattern: /syntax error.*?['"]?GRUOP['"]?/i, suggestion: 'Did you mean GROUP?' },
    { pattern: /syntax error.*?['"]?ODER['"]?/i, suggestion: 'Did you mean ORDER?' },
    { pattern: /unexpected end/i, suggestion: 'Query seems incomplete. Check for missing clauses.' },
    { pattern: /missing.*?from/i, suggestion: 'Add a FROM clause to specify the table.' },
    { pattern: /invalid identifier/i, suggestion: 'Column or table name not found. Check spelling.' },
    { pattern: /ambiguous.*?column/i, suggestion: 'Qualify the column with its table name (e.g., table.column).' },
    { pattern: /object.*?does not exist/i, suggestion: 'Table or database not found. Check if it exists.' },
    { pattern: /permission denied/i, suggestion: 'You don\'t have access to this object.' },
    { pattern: /compilation error/i, suggestion: 'SQL syntax issue. Review the highlighted line.' },
  ];
  
  let suggestion = null;
  for (const { pattern, suggestion: sug } of typoPatterns) {
    if (pattern.test(errorStr)) {
      suggestion = sug;
      break;
    }
  }
  
  // Shorten overly long error messages
  let shortError = errorStr;
  if (shortError.length > 200) {
    shortError = shortError.substring(0, 200) + '...';
  }
  
  return { line, suggestion, shortError, fullError: errorStr };
}

// Compact results table for the flyout
function CompactResultsTable({ results, loading, error }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-8 text-blue-600">
        <Loader2 size={24} className="animate-spin mr-2" />
        <span className="text-sm font-medium">Executing query...</span>
      </div>
    );
  }

  if (error) {
    const { line, suggestion, shortError } = parseSqlError(error);
    
    return (
      <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg">
        <div className="flex items-start gap-3">
          <div className="p-1.5 bg-rose-100 rounded-full flex-shrink-0">
            <AlertCircle size={16} className="text-rose-500" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-medium text-rose-700 text-sm">Query Error</p>
              {line && (
                <span className="text-xs px-1.5 py-0.5 bg-rose-100 text-rose-600 rounded">
                  Line {line}
                </span>
              )}
            </div>
            {suggestion && (
              <p className="text-rose-600 text-sm mt-1.5 flex items-center gap-1.5">
                <span className="text-rose-400">💡</span>
                {suggestion}
              </p>
            )}
            <p className="text-rose-600/80 text-xs mt-2 font-mono bg-rose-100/50 p-2 rounded break-words">
              {shortError}
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-gray-400">
        <Database size={32} className="mb-2 opacity-50" />
        <p className="text-sm">Click "Run" to execute the query</p>
      </div>
    );
  }

  const { columns, rows, rowCount, executionTime } = results;

  if (rows.length === 0) {
    return (
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="flex items-start gap-2">
          <AlertCircle size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-amber-700 text-sm">Query returned no rows</p>
            <p className="text-amber-600 text-xs mt-1">
              The table may be empty or no rows match your query conditions.
            </p>
            {columns?.length > 0 && (
              <p className="text-amber-600 text-xs mt-1">
                Columns found: {columns.slice(0, 5).map(c => typeof c === 'string' ? c : c.name).join(', ')}
                {columns.length > 5 && ` +${columns.length - 5} more`}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Get column names
  const colNames = columns?.map(c => typeof c === 'string' ? c : c.name) || Object.keys(rows[0] || {});

  return (
    <div>
      {/* Results header */}
      <div className="flex items-center justify-between mb-2 px-1">
        <div className="flex items-center gap-3 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <Check size={12} className="text-green-500" />
            <strong className="text-gray-700">{rowCount?.toLocaleString() || rows.length}</strong> rows
          </span>
          {executionTime && (
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {(executionTime / 1000).toFixed(2)}s
            </span>
          )}
        </div>
        <span className="text-xs text-gray-400">{colNames.length} columns</span>
      </div>

      {/* Results table */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg bg-white">
        <table className="w-full text-xs">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              {colNames.slice(0, 8).map((col, i) => (
                <th key={i} className="px-3 py-2 text-left font-medium text-gray-600 border-b border-gray-200 whitespace-nowrap">
                  {col}
                </th>
              ))}
              {colNames.length > 8 && (
                <th className="px-3 py-2 text-left text-gray-400 border-b border-gray-200">
                  +{colNames.length - 8} more
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 50).map((row, rowIdx) => (
              <tr key={rowIdx} className="hover:bg-blue-50 border-b border-gray-100 last:border-0">
                {colNames.slice(0, 8).map((col, colIdx) => (
                  <td key={colIdx} className="px-3 py-2 max-w-[200px] truncate">
                    {row[colIdx] !== null && row[colIdx] !== undefined 
                      ? String(row[colIdx]).substring(0, 100)
                      : <span className="text-gray-300 italic">null</span>
                    }
                  </td>
                ))}
                {colNames.length > 8 && (
                  <td className="px-3 py-2 text-gray-300">...</td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > 50 && (
          <div className="px-3 py-2 bg-gray-50 text-xs text-gray-500 text-center border-t border-gray-200">
            Showing 50 of {rows.length} rows
          </div>
        )}
      </div>
    </div>
  );
}

// Copy button
function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = async (e) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  
  return (
    <button
      onClick={handleCopy}
      className={`p-1.5 rounded transition-all ${
        copied 
          ? 'bg-green-100 text-green-600' 
          : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700'
      }`}
      title={copied ? 'Copied!' : 'Copy SQL'}
    >
      {copied ? <Check size={14} /> : <Copy size={14} />}
    </button>
  );
}

export default function FlyoutQueryEditor({ 
  initialQuery = '', 
  title = 'Test Query',
  onClose,
  onOpenFullEditor,
  database,
  schema
}) {
  const editorRef = useRef(null);
  const [sql, setSql] = useState(initialQuery);
  const [isExpanded, setIsExpanded] = useState(true);
  
  const { status: connStatus } = useConnection();
  const { executeQuery, results, loading, error, clearResults } = useQuery();
  
  // Update SQL when initialQuery changes
  useEffect(() => {
    if (initialQuery) {
      setSql(initialQuery);
      clearResults();
    }
  }, [initialQuery, clearResults]);

  // ESC key to close flyout
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose?.();
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [onClose]);

  // Check for reduced motion preference
  const prefersReducedMotion = typeof window !== 'undefined' 
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches 
    : false;

  // Handle editor mount - auto-focus for immediate typing
  const handleEditorMount = (editor, monaco) => {
    editorRef.current = editor;
    
    // Auto-focus editor for immediate typing
    setTimeout(() => {
      editor.focus();
    }, 100);
    
    // Add Cmd/Ctrl+Enter to execute
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      handleExecute();
    });
  };

  // Execute query
  const handleExecute = useCallback(async () => {
    const queryText = sql.trim();
    if (!queryText) return;
    
    await executeQuery(queryText, {
      database: database || connStatus?.database,
      schema: schema || connStatus?.schema,
      warehouse: connStatus?.warehouse
    });
  }, [sql, database, schema, connStatus, executeQuery]);

  // Reset to initial query
  const handleReset = useCallback(() => {
    setSql(initialQuery);
    clearResults();
  }, [initialQuery, clearResults]);

  const isConnected = connStatus?.connected;

  return (
    <div 
      className="flex flex-col h-full bg-white"
      role="dialog"
      aria-modal="true"
      aria-labelledby="flyout-title"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-blue-100 rounded-lg">
            <Play size={16} className="text-blue-600" />
          </div>
          <div>
            <h3 
              id="flyout-title"
              className="font-semibold text-gray-800 text-sm flex items-center gap-1.5"
            >
              {title}
              {sql !== initialQuery && (
                <span 
                  className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" 
                  title="Unsaved changes"
                  aria-label="Query has been modified"
                />
              )}
            </h3>
            {/* Context Badge - shows database.schema */}
            <div className="flex items-center gap-2 mt-1">
              {isConnected ? (
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                  <Snowflake size={10} />
                  {database || connStatus?.database || 'Default'}.{schema || connStatus?.schema || 'PUBLIC'}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-gray-100 text-gray-500 rounded text-xs">
                  <WifiOff size={10} />
                  Not connected
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <CopyButton text={sql} />
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded text-gray-500 hover:text-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-gray-400"
            title="Close (Esc)"
            aria-label="Close flyout editor"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Not connected warning - reserved space to prevent layout shift */}
      <div className="min-h-[40px]">
        {!isConnected && (
          <div className="px-4 py-2 bg-amber-50 border-b border-amber-200">
            <p className="text-xs text-amber-700 flex items-center gap-2">
              <WifiOff size={14} />
              Click the Snowflake button in the header to connect and run queries
            </p>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Collapsible SQL Editor */}
        <div className={`border-b border-gray-200 ${prefersReducedMotion ? '' : 'transition-all duration-200'} ${isExpanded ? 'h-[200px]' : 'h-10'}`}>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full flex items-center justify-between px-4 py-2 bg-gray-50 hover:bg-gray-100 text-xs font-medium text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-inset"
            aria-expanded={isExpanded}
            aria-controls="sql-editor"
          >
            <span className="flex items-center gap-2">
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              SQL Editor
            </span>
            <span className="text-gray-400">
              {sql.split('\n').length} lines
            </span>
          </button>
          
          {isExpanded && (
            <div id="sql-editor" className="h-[calc(100%-32px)]">
              <Editor
                height="100%"
                defaultLanguage="sql"
                value={sql}
                onChange={(value) => setSql(value || '')}
                onMount={handleEditorMount}
                theme="vs"
                options={{
                  minimap: { enabled: false },
                  fontSize: 12,
                  lineNumbers: 'on',
                  scrollBeyondLastLine: false,
                  wordWrap: 'on',
                  automaticLayout: true,
                  tabSize: 2,
                  padding: { top: 8 },
                  lineNumbersMinChars: 3,
                  folding: false,
                  renderLineHighlight: 'line',
                  scrollbar: {
                    vertical: 'auto',
                    horizontal: 'auto',
                    verticalScrollbarSize: 8,
                    horizontalScrollbarSize: 8,
                  }
                }}
              />
            </div>
          )}
        </div>

        {/* Results Section - scrollable */}
        <div className="flex-1 overflow-auto p-4">
          <CompactResultsTable 
            results={results} 
            loading={loading} 
            error={error} 
          />
        </div>
      </div>

      {/* Sticky Footer with Actions */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-t border-gray-200 bg-gray-50">
        <div className="flex items-center gap-2">
          <button
            onClick={handleExecute}
            disabled={loading || !sql.trim() || !isConnected}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            aria-label="Execute SQL query"
          >
            {loading ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Play size={14} />
            )}
            {loading ? 'Running...' : 'Run Query'}
          </button>
          
          {sql !== initialQuery && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-2 hover:bg-gray-200 text-gray-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              title="Reset to original query"
              aria-label="Reset query to original"
            >
              <RotateCcw size={14} />
              Reset
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400 hidden sm:inline">
            ⌘+Enter to run
          </span>
          {onOpenFullEditor && (
            <button
              onClick={() => onOpenFullEditor(sql)}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              title="Open in full Query Editor"
              aria-label="Open query in full editor"
            >
              <Maximize2 size={14} />
              Full Editor
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

