/**
 * FlyoutQueryEditor - Embedded SQL editor for the flyout panel
 * 
 * A compact SQL editor with execution capabilities that can be
 * embedded within the QueryPanel flyout for testing queries inline.
 * 
 * Features:
 * - Simplified 2-row header layout (can be hidden when used in TestQueryLayout)
 * - Unsaved changes tracking with callback
 * - Collapsible SQL editor
 * - Compact results table
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Editor from '@monaco-editor/react';
import { 
  Play, X, Loader2, Check, AlertCircle, ChevronDown, ChevronRight,
  Copy, Database, Clock, RotateCcw, Maximize2, WifiOff, Snowflake, Trash2
} from 'lucide-react';
import { useQuery, useConnection } from '../hooks/useSnowflake';

// Parse SQL errors into friendly messages with missing table detection
function parseSqlError(error) {
  const errorStr = String(error);
  
  // Extract line number if present
  const lineMatch = errorStr.match(/line\s+(\d+)/i) || errorStr.match(/at\s+position.*?line\s+(\d+)/i);
  const line = lineMatch ? parseInt(lineMatch[1], 10) : null;
  
  // Extract missing table/object name from error
  let missingTable = null;
  const objectPatterns = [
    /Object\s+'([^']+)'\s+does not exist/i,
    /Table\s+'([^']+)'\s+does not exist/i,
    /relation\s+"([^"]+)"\s+does not exist/i,
    /Unknown table\s+'([^']+)'/i,
    /'([A-Z_]+_ENTITY)'\s+does not exist/i,
  ];
  
  for (const pattern of objectPatterns) {
    const match = errorStr.match(pattern);
    if (match) {
      missingTable = match[1];
      break;
    }
  }
  
  // Determine error type for better UI
  let errorType = 'generic';
  let suggestion = null;
  
  if (missingTable) {
    errorType = 'missing_table';
    suggestion = `Table "${missingTable}" doesn't exist. Run "SHOW TABLES IN SCHEMA" to see available tables.`;
  } else {
    const typoPatterns = [
      { pattern: /syntax error.*?['"]?SELEC['"]?/i, suggestion: 'Did you mean SELECT?' },
      { pattern: /syntax error.*?['"]?FORM['"]?/i, suggestion: 'Did you mean FROM?' },
      { pattern: /syntax error.*?['"]?WEHERE['"]?/i, suggestion: 'Did you mean WHERE?' },
      { pattern: /syntax error.*?['"]?GRUOP['"]?/i, suggestion: 'Did you mean GROUP?' },
      { pattern: /syntax error.*?['"]?ODER['"]?/i, suggestion: 'Did you mean ORDER?' },
      { pattern: /unexpected end/i, suggestion: 'Query seems incomplete. Check for missing clauses.' },
      { pattern: /missing.*?from/i, suggestion: 'Add a FROM clause to specify the table.' },
      { pattern: /invalid identifier/i, suggestion: 'Column or table name not found. Check spelling.', type: 'invalid_identifier' },
      { pattern: /ambiguous.*?column/i, suggestion: 'Qualify the column with its table name (e.g., table.column).' },
      { pattern: /permission denied/i, suggestion: 'You don\'t have access to this object.', type: 'permission' },
      { pattern: /compilation error/i, suggestion: 'SQL syntax issue. Review the highlighted line.', type: 'syntax' },
      { pattern: /not authorized/i, suggestion: 'You don\'t have permission to access this object.', type: 'permission' },
    ];
    
    for (const { pattern, suggestion: sug, type } of typoPatterns) {
      if (pattern.test(errorStr)) {
        suggestion = sug;
        if (type) errorType = type;
        break;
      }
    }
  }
  
  let shortError = errorStr;
  if (shortError.length > 250) {
    const coreMatch = errorStr.match(/(?:error|failed):\s*(.{1,200})/i);
    if (coreMatch) {
      shortError = coreMatch[1] + '...';
    } else {
      shortError = errorStr.substring(0, 250) + '...';
    }
  }
  
  return { line, suggestion, shortError, fullError: errorStr, missingTable, errorType };
}

// Compact results table for the flyout
function CompactResultsTable({ results, loading, error }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-8 text-blue-600">
        <Loader2 size={24} className="animate-spin mr-2" />
        <span className="text-sm font-medium">Executing query...</span>
      </div>
    );
  }

  if (error) {
    const { line, suggestion, shortError, missingTable, errorType } = parseSqlError(error);
    
    const isMissingTable = errorType === 'missing_table';
    const bgColor = isMissingTable ? 'bg-amber-50' : 'bg-rose-50';
    const borderColor = isMissingTable ? 'border-amber-200' : 'border-rose-200';
    const iconBg = isMissingTable ? 'bg-amber-100' : 'bg-rose-100';
    const iconColor = isMissingTable ? 'text-amber-500' : 'text-rose-500';
    const textColor = isMissingTable ? 'text-amber-700' : 'text-rose-700';
    const subTextColor = isMissingTable ? 'text-amber-600' : 'text-rose-600';
    
    return (
      <div className={`p-4 ${bgColor} border ${borderColor} rounded-xl`}>
        <div className="flex items-start gap-3">
          <div className={`p-1.5 ${iconBg} rounded-full flex-shrink-0`}>
            {isMissingTable ? (
              <Database size={16} className={iconColor} />
            ) : (
              <AlertCircle size={16} className={iconColor} />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className={`font-medium ${textColor} text-sm`}>
                {isMissingTable ? 'Table Not Found' : 'Query Error'}
              </p>
              {missingTable && (
                <span className="text-xs px-2 py-0.5 bg-amber-200 text-amber-800 rounded font-mono">
                  {missingTable}
                </span>
              )}
              {line && !missingTable && (
                <span className="text-xs px-1.5 py-0.5 bg-rose-100 text-rose-600 rounded">
                  Line {line}
                </span>
              )}
            </div>
            {suggestion && (
              <p className={`${subTextColor} text-sm mt-1.5 flex items-start gap-1.5`}>
                <span className="flex-shrink-0">💡</span>
                <span>{suggestion}</span>
              </p>
            )}
            {isMissingTable && (
              <div className="mt-3 p-2 bg-amber-100/50 rounded border border-amber-200/50">
                <p className="text-amber-700 text-xs font-medium mb-1">Quick check:</p>
                <code className="text-amber-800 text-xs font-mono block">
                  SHOW TABLES LIKE '%{missingTable?.replace('_ENTITY', '')}%' IN SCHEMA;
                </code>
              </div>
            )}
            <details className="mt-2">
              <summary className={`${subTextColor}/80 text-xs cursor-pointer hover:underline`}>
                Show full error
              </summary>
              <p className={`${subTextColor}/70 text-xs mt-1 font-mono ${isMissingTable ? 'bg-amber-100/50' : 'bg-rose-100/50'} p-2 rounded break-words`}>
                {shortError}
              </p>
            </details>
          </div>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-gray-400">
        <Database size={32} className="mb-2 opacity-50" />
        <p className="text-sm">Click "Run query" to execute</p>
        <p className="text-xs mt-1 text-gray-300">⌘+Enter for quick run</p>
      </div>
    );
  }

  const { columns, rows, rowCount, executionTime } = results;

  if (rows.length === 0) {
    return (
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
        <div className="flex items-start gap-2">
          <AlertCircle size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-amber-700 text-sm">Query returned no rows</p>
            <p className="text-amber-600 text-xs mt-1">
              The table may be empty or no rows match your query conditions.
            </p>
            {columns?.length > 0 && (
              <p className="text-amber-600 text-xs mt-1">
                Columns found: {columns.slice(0, 5).map(c => typeof c === 'string' ? c : c.name).join(', ')}
                {columns.length > 5 && ` +${columns.length - 5} more`}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  const colNames = columns?.map(c => typeof c === 'string' ? c : c.name) || Object.keys(rows[0] || {});

  return (
    <div>
      {/* Results header */}
      <div className="flex items-center justify-between mb-2 px-1">
        <div className="flex items-center gap-3 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <Check size={12} className="text-green-500" />
            <strong className="text-gray-700">{rowCount?.toLocaleString() || rows.length}</strong> rows
          </span>
          {executionTime && (
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {(executionTime / 1000).toFixed(2)}s
            </span>
          )}
        </div>
        <span className="text-xs text-gray-400">{colNames.length} columns</span>
      </div>

      {/* Results table */}
      <div className="overflow-x-auto border border-gray-200 rounded-xl bg-white">
        <table className="w-full text-xs">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              {colNames.slice(0, 8).map((col, i) => (
                <th key={i} className="px-3 py-2 text-left font-medium text-gray-600 border-b border-gray-200 whitespace-nowrap">
                  {col}
                </th>
              ))}
              {colNames.length > 8 && (
                <th className="px-3 py-2 text-left text-gray-400 border-b border-gray-200">
                  +{colNames.length - 8} more
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 50).map((row, rowIdx) => (
              <tr key={rowIdx} className="hover:bg-blue-50 border-b border-gray-100 last:border-0">
                {colNames.slice(0, 8).map((col, colIdx) => (
                  <td key={colIdx} className="px-3 py-2 max-w-[200px] truncate">
                    {row[colIdx] !== null && row[colIdx] !== undefined 
                      ? String(row[colIdx]).substring(0, 100)
                      : <span className="text-gray-300 italic">null</span>
                    }
                  </td>
                ))}
                {colNames.length > 8 && (
                  <td className="px-3 py-2 text-gray-300">...</td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > 50 && (
          <div className="px-3 py-2 bg-gray-50 text-xs text-gray-500 text-center border-t border-gray-200">
            Showing 50 of {rows.length} rows
          </div>
        )}
      </div>
    </div>
  );
}

// Copy button
function CopyButton({ text, size = 14 }) {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = async (e) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  
  return (
    <button
      onClick={handleCopy}
      className={`p-1.5 rounded transition-all ${
        copied 
          ? 'bg-green-100 text-green-600' 
          : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700'
      }`}
      title={copied ? 'Copied!' : 'Copy SQL'}
    >
      {copied ? <Check size={size} /> : <Copy size={size} />}
    </button>
  );
}

// ============================================================================
// FlyoutQueryEditorHeader - 2-row simplified header
// ============================================================================

function FlyoutQueryEditorHeader({
  title,
  hasUnsavedChanges,
  onRun,
  running,
  database,
  schema,
  isConnected,
  onOpenFullEditor,
  onClearResults,
  hasResults,
  onCopy,
  sql
}) {
  return (
    <div className="border-b border-gray-200 bg-white px-4 py-3 space-y-2 flex-shrink-0">
      {/* Row 1: Title + unsaved dot | Run button */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex-shrink-0">
            <Play size={14} />
          </span>
          <div className="flex items-center gap-2 min-w-0">
            <h3 className="text-sm font-semibold text-gray-900 truncate">{title}</h3>
            {hasUnsavedChanges && (
              <span 
                className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0" 
                title="Unsaved changes" 
              />
            )}
          </div>
        </div>
        <button
          onClick={onRun}
          disabled={running || !isConnected}
          className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-lg border border-emerald-500 text-emerald-600 hover:bg-emerald-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {running ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
          <span>{running ? 'Running…' : 'Run query'}</span>
        </button>
      </div>

      {/* Row 2: Context | Utilities */}
      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="inline-flex items-center gap-1.5">
          {isConnected ? (
            <>
              <Snowflake size={12} className="text-blue-500" />
              <span className="font-mono">
                {database || 'Default'}.{schema || 'PUBLIC'}
              </span>
            </>
          ) : (
            <>
              <WifiOff size={12} className="text-gray-400" />
              <span>Not connected</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          <CopyButton text={sql} size={12} />
          {hasResults && onClearResults && (
            <button
              onClick={onClearResults}
              className="inline-flex items-center gap-1 hover:text-gray-700 transition-colors"
              title="Clear results"
            >
              <Trash2 size={12} />
              <span>Clear</span>
            </button>
          )}
          {onOpenFullEditor && (
            <button
              onClick={onOpenFullEditor}
              className="inline-flex items-center gap-1 hover:text-gray-700 transition-colors"
              title="Open in full Query Editor"
            >
              <Maximize2 size={12} />
              <span>Full editor</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// Main FlyoutQueryEditor Component
// ============================================================================

export default function FlyoutQueryEditor({ 
  initialQuery = '', 
  title = 'Test Query',
  onClose,
  onOpenFullEditor,
  database,
  schema,
  // New props for integration with TestQueryLayout
  hideHeader = false,
  onSqlChange = null
}) {
  const editorRef = useRef(null);
  const [sql, setSql] = useState(initialQuery);
  const [isExpanded, setIsExpanded] = useState(true);
  
  const { status: connStatus } = useConnection();
  const { executeQuery, results, loading, error, clearResults } = useQuery();
  
  // Update SQL when initialQuery changes
  useEffect(() => {
    if (initialQuery) {
      setSql(initialQuery);
      clearResults();
    }
  }, [initialQuery, clearResults]);
  
  // Notify parent of SQL changes (for unsaved changes tracking)
  useEffect(() => {
    if (onSqlChange) {
      onSqlChange(sql, initialQuery);
    }
  }, [sql, initialQuery, onSqlChange]);

  // Check for reduced motion preference
  const prefersReducedMotion = typeof window !== 'undefined' 
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches 
    : false;

  // Handle editor mount - auto-focus for immediate typing
  const handleEditorMount = (editor, monaco) => {
    editorRef.current = editor;
    
    setTimeout(() => {
      editor.focus();
    }, 100);
    
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      handleExecute();
    });
  };

  // Execute query
  const handleExecute = useCallback(async () => {
    const queryText = sql.trim();
    if (!queryText) return;
    
    await executeQuery(queryText, {
      database: database || connStatus?.database,
      schema: schema || connStatus?.schema,
      warehouse: connStatus?.warehouse
    });
  }, [sql, database, schema, connStatus, executeQuery]);

  // Reset to initial query
  const handleReset = useCallback(() => {
    setSql(initialQuery);
    clearResults();
  }, [initialQuery, clearResults]);
  
  // Clear results only
  const handleClearResults = useCallback(() => {
    clearResults();
  }, [clearResults]);
  
  // Open in full editor
  const handleOpenFullEditor = useCallback(() => {
    if (onOpenFullEditor) {
      onOpenFullEditor(sql);
    }
  }, [onOpenFullEditor, sql]);

  const isConnected = connStatus?.connected;
  const hasUnsavedChanges = sql !== initialQuery;

  return (
    <div 
      className="flex flex-col h-full bg-white"
      role="region"
      aria-label="SQL Query Editor"
    >
      {/* Header - hidden when used inside TestQueryLayout */}
      {!hideHeader && (
        <FlyoutQueryEditorHeader
          title={title}
          hasUnsavedChanges={hasUnsavedChanges}
          onRun={handleExecute}
          running={loading}
          database={database || connStatus?.database}
          schema={schema || connStatus?.schema}
          isConnected={isConnected}
          onOpenFullEditor={handleOpenFullEditor}
          onClearResults={handleClearResults}
          hasResults={!!results}
          sql={sql}
        />
      )}

      {/* Not connected warning */}
      {!isConnected && (
        <div className="px-4 py-2 bg-amber-50 border-b border-amber-200 flex-shrink-0">
          <p className="text-xs text-amber-700 flex items-center gap-2">
            <WifiOff size={14} />
            Connect to Snowflake to run queries
          </p>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Collapsible SQL Editor */}
        <div className={`border-b border-gray-200 ${prefersReducedMotion ? '' : 'transition-all duration-200'} ${isExpanded ? 'h-[200px]' : 'h-10'}`}>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full flex items-center justify-between px-4 py-2 bg-gray-50 hover:bg-gray-100 text-xs font-medium text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-inset"
            aria-expanded={isExpanded}
            aria-controls="sql-editor"
          >
            <span className="flex items-center gap-2">
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              SQL Editor
              {hasUnsavedChanges && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
              )}
            </span>
            <span className="text-gray-400">
              {sql.split('\n').length} lines
            </span>
          </button>
          
          {isExpanded && (
            <div id="sql-editor" className="h-[calc(100%-32px)]">
              <Editor
                height="100%"
                defaultLanguage="sql"
                value={sql}
                onChange={(value) => setSql(value || '')}
                onMount={handleEditorMount}
                theme="vs"
                options={{
                  minimap: { enabled: false },
                  fontSize: 12,
                  lineNumbers: 'on',
                  scrollBeyondLastLine: false,
                  wordWrap: 'on',
                  automaticLayout: true,
                  tabSize: 2,
                  padding: { top: 8 },
                  lineNumbersMinChars: 3,
                  folding: false,
                  renderLineHighlight: 'line',
                  scrollbar: {
                    vertical: 'auto',
                    horizontal: 'auto',
                    verticalScrollbarSize: 8,
                    horizontalScrollbarSize: 8,
                  }
                }}
              />
            </div>
          )}
        </div>

        {/* Results Section - scrollable */}
        <div className="flex-1 overflow-auto p-4">
          <CompactResultsTable 
            results={results} 
            loading={loading} 
            error={error} 
          />
        </div>
      </div>

      {/* Sticky Footer with Actions */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-t border-gray-200 bg-gray-50">
        <div className="flex items-center gap-2">
          <button
            onClick={handleExecute}
            disabled={loading || !sql.trim() || !isConnected}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
            aria-label="Execute SQL query"
          >
            {loading ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Play size={14} />
            )}
            {loading ? 'Running...' : 'Run query'}
          </button>
          
          {hasUnsavedChanges && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-2 hover:bg-gray-200 text-gray-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              title="Reset to original query"
              aria-label="Reset query to original"
            >
              <RotateCcw size={14} />
              Reset
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400 hidden sm:inline">
            ⌘+Enter to run
          </span>
          {onOpenFullEditor && (
            <button
              onClick={handleOpenFullEditor}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              title="Open in full Query Editor"
              aria-label="Open query in full editor"
            >
              <Maximize2 size={14} />
              Full Editor
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
