"""Application configuration from environment variables."""

from pydantic_settings import BaseSettings
from typing import Optional, List
import os


class Settings(BaseSettings):
    """Snowflake and server configuration."""
    
    # Snowflake Connection
    snowflake_account: str = ""
    snowflake_user: str = ""
    snowflake_private_key_path: Optional[str] = None
    snowflake_password: Optional[str] = None
    snowflake_warehouse: str = "COMPUTE_WH"
    snowflake_database: str = "ATLAN_MDLH"
    snowflake_schema: str = "PUBLIC"
    snowflake_role: Optional[str] = None
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # CORS Configuration
    # Set CORS_ORIGINS environment variable to a comma-separated list of allowed origins
    # Example: CORS_ORIGINS=https://myapp.example.com,https://staging.example.com
    cors_origins: str = "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173,http://127.0.0.1:3000"
    
    # Cache TTLs (seconds) - matches frontend TIMEOUTS
    cache_ttl_databases: int = 600  # 10 minutes
    cache_ttl_schemas: int = 600    # 10 minutes
    cache_ttl_tables: int = 600     # 10 minutes
    cache_ttl_columns: int = 900    # 15 minutes
    
    @property
    def cors_origins_list(self) -> List[str]:
        """Parse CORS origins from comma-separated string."""
        if not self.cors_origins:
            return []
        return [origin.strip() for origin in self.cors_origins.split(',') if origin.strip()]
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()

