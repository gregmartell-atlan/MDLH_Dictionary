/**
 * Find by GUID SQL Builder
 * 
 * Generates queries to find assets by their GUID.
 * Uses safe approaches that work across different schemas.
 */

/**
 * Build a query to find an asset by GUID
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildFindByGuidQuery(entity, inputs, availableTables = []) {
  const guid = entity.guid || inputs.filters?.guid || '<YOUR_GUID_HERE>';
  const db = entity.database || 'FIELD_METADATA';
  const schema = entity.schema || 'PUBLIC';
  
  // Find tables that likely contain GUIDs (end with _ENTITY)
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const entityTables = tables.filter(t => t.endsWith('_ENTITY'));
  
  // If no entity tables, provide discovery query
  if (entityTables.length === 0) {
    const sql = `
-- No entity tables found in your schema
-- Let's discover what tables are available

SHOW TABLES LIKE '%_ENTITY%' IN ${db}.${schema};

-- Or search all tables:
-- SHOW TABLES IN ${db}.${schema};
`.trim();

    return {
      title: `🔍 Find Entity Tables`,
      description: `Discover tables that contain asset metadata.`,
      sql,
      database: db,
      schema,
      timeoutSeconds: 30,
      flowType: 'FIND_BY_GUID',
      entity,
    };
  }
  
  // Pick first few entity tables to search (don't try too many at once)
  const tablesToSearch = entityTables.slice(0, 5);
  
  // Build a simple search - use SELECT * to avoid column name issues
  const searchQueries = tablesToSearch.map(table => 
    `-- Search in ${table}\nSELECT * FROM ${db}.${schema}.${table} WHERE guid = '${guid}' LIMIT 1;`
  ).join('\n\n');
  
  const sql = `
-- Find asset by GUID: ${guid}
-- Searching ${tablesToSearch.length} entity tables

-- Run each query separately (Snowflake doesn't support multiple statements)
-- Or use UNION ALL below

${searchQueries}

-- Alternative: UNION ALL approach (may fail if column schemas differ)
/*
${tablesToSearch.map(table => 
  `SELECT '${table}' as source_table, * FROM ${db}.${schema}.${table} WHERE guid = '${guid}'`
).join('\nUNION ALL\n')}
LIMIT 1;
*/
`.trim();

  return {
    title: `🔍 Find: ${guid.substring(0, 12)}...`,
    description: `Search for GUID in ${tablesToSearch.length} entity tables.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    flowType: 'FIND_BY_GUID',
    entity,
  };
}

/**
 * Build a simple query to get full details from a specific table
 * This always works - just SELECT * WHERE guid = X
 */
export function buildGuidDetailsQuery(guid, entityTable, entity) {
  const db = entity?.database || 'FIELD_METADATA';
  const schema = entity?.schema || 'PUBLIC';
  
  const sql = `
-- Get full details for GUID: ${guid}
-- Table: ${entityTable}

SELECT *
FROM ${db}.${schema}.${entityTable}
WHERE guid = '${guid}'
LIMIT 1;
`.trim();

  return {
    title: `📄 Details: ${guid.substring(0, 12)}...`,
    description: `Full metadata from ${entityTable}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    flowType: 'FIND_BY_GUID',
    entity,
  };
}

export default buildFindByGuidQuery;
