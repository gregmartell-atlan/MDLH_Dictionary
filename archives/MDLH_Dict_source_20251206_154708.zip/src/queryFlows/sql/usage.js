/**
 * Usage SQL Builder
 * 
 * Generates queries to find how assets are being used.
 */

/**
 * Build a usage query for the given entity
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildUsageQuery(entity, inputs, availableTables = []) {
  const { daysBack = 30, rowLimit = 500 } = inputs;
  const assetName = entity.name || entity.qualifiedName || entity.guid || '<ASSET_NAME>';
  
  // Check if we have usage-related tables
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const hasQueryHistory = tables.some(t => t.includes('QUERY') && t.includes('HISTORY'));
  
  let sql;
  
  if (hasQueryHistory) {
    // Use MDLH query history if available
    sql = `
-- Usage: queries referencing "${assetName}" in last ${daysBack} days

SELECT
    query_id,
    start_time,
    user_name,
    LEFT(query_text, 500) AS query_preview,
    rows_scanned,
    rows_returned,
    execution_time_ms
FROM QUERY_HISTORY_ENTITY
WHERE start_time >= DATEADD('day', -${daysBack}, CURRENT_TIMESTAMP())
  AND query_text ILIKE '%${assetName}%'
ORDER BY start_time DESC
LIMIT ${rowLimit};
`.trim();
  } else {
    // Fallback: use Snowflake's ACCOUNT_USAGE if accessible
    sql = `
-- Usage: queries referencing "${assetName}" in last ${daysBack} days
-- Note: Requires access to SNOWFLAKE.ACCOUNT_USAGE

SELECT
    query_id,
    start_time,
    user_name,
    LEFT(query_text, 500) AS query_preview,
    rows_produced,
    total_elapsed_time / 1000 AS execution_time_ms
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE start_time >= DATEADD('day', -${daysBack}, CURRENT_TIMESTAMP())
  AND query_text ILIKE '%${assetName}%'
ORDER BY start_time DESC
LIMIT ${rowLimit};
`.trim();
  }

  return {
    title: `📊 Usage: ${assetName}`,
    description: `Queries that reference ${assetName} in the last ${daysBack} days.`,
    sql,
    database: entity.database,
    schema: entity.schema,
    timeoutSeconds: 60,
    limit: rowLimit,
    flowType: 'USAGE',
    entity,
  };
}

/**
 * Build a query to find popular assets
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildPopularityQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 100 } = inputs;
  const db = entity.database || 'FIELD_METADATA';
  const schema = entity.schema || 'PUBLIC';
  
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const hasTableEntity = tables.includes('TABLE_ENTITY');
  
  if (!hasTableEntity) {
    return {
      title: '🔥 Popular Assets',
      description: 'TABLE_ENTITY not found in schema.',
      sql: `-- TABLE_ENTITY not available\nSHOW TABLES;`,
      flowType: 'USAGE',
      entity,
    };
  }

  const sql = `
-- Popular tables by query count and popularity score

SELECT
    name,
    typename,
    guid,
    querycount AS query_count,
    queryusercount AS unique_users,
    popularityscore AS popularity_score,
    databasename,
    schemaname
FROM TABLE_ENTITY
WHERE querycount > 0
ORDER BY popularityscore DESC, querycount DESC
LIMIT ${rowLimit};
`.trim();

  return {
    title: '🔥 Most Popular Tables',
    description: `Tables ranked by usage and popularity in ${db}.${schema}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    flowType: 'USAGE',
    entity,
  };
}

export default buildUsageQuery;

