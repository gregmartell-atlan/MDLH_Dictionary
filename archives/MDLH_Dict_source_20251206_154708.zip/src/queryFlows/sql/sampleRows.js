/**
 * Sample Rows SQL Builder
 * 
 * Generates queries to preview data from tables and views.
 */

/**
 * Build a sample rows query for the given entity
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildSampleRowsQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 100 } = inputs;
  
  const db = entity.database || '<DATABASE>';
  const schema = entity.schema || '<SCHEMA>';
  const table = entity.table || entity.name || '<TABLE>';
  
  // Build fully qualified name
  const fqn = `"${db}"."${schema}"."${table}"`;
  
  const sql = `
-- Sample rows from ${fqn}
-- Limit: ${rowLimit} rows

SELECT *
FROM ${fqn}
LIMIT ${rowLimit};
`.trim();

  return {
    title: `👀 Sample: ${table}`,
    description: `Preview ${rowLimit} rows from ${fqn}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    limit: rowLimit,
    flowType: 'SAMPLE_ROWS',
    entity,
  };
}

/**
 * Build a query to get row count and basic stats
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @returns {import('../types').BuiltQuery}
 */
export function buildTableStatsQuery(entity, inputs) {
  const db = entity.database || '<DATABASE>';
  const schema = entity.schema || '<SCHEMA>';
  const table = entity.table || entity.name || '<TABLE>';
  const fqn = `"${db}"."${schema}"."${table}"`;

  const sql = `
-- Table statistics for ${fqn}

SELECT
    COUNT(*) AS total_rows,
    COUNT(*) - COUNT(DISTINCT *) AS duplicate_rows,
    '${table}' AS table_name
FROM ${fqn};
`.trim();

  return {
    title: `📈 Stats: ${table}`,
    description: `Row count and basic statistics for ${fqn}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 60,
    flowType: 'SAMPLE_ROWS',
    entity,
  };
}

export default buildSampleRowsQuery;

