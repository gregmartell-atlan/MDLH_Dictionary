/**
 * Glossary SQL Builder
 * 
 * Generates queries for glossary term lookups and relationships.
 */

/**
 * Build a glossary lookup query
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildGlossaryQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 200, filters = {} } = inputs;
  const termName = filters.termName || entity.name || '<TERM>';
  
  // Check available glossary tables
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const glossaryTable = tables.includes('ATLASGLOSSARY_ENTITY') 
    ? 'ATLASGLOSSARY_ENTITY' 
    : tables.find(t => t.includes('GLOSSARY') && !t.includes('TERM') && !t.includes('CATEGORY'));
  
  const termTable = tables.includes('ATLASGLOSSARYTERM_ENTITY')
    ? 'ATLASGLOSSARYTERM_ENTITY'
    : tables.includes('GLOSSARYTERM_ENTITY')
    ? 'GLOSSARYTERM_ENTITY'
    : tables.find(t => t.includes('GLOSSARY') && t.includes('TERM'));
  
  if (!termTable) {
    return {
      title: `📖 Glossary: ${termName}`,
      description: 'No glossary tables found in schema.',
      sql: `-- No GLOSSARYTERM_ENTITY found\n-- Run this to find glossary tables:\nSHOW TABLES LIKE '%GLOSSARY%';`,
      flowType: 'GLOSSARY_LOOKUP',
      entity,
    };
  }

  const sql = `
-- Glossary: terms matching "${termName}"
-- Using ${termTable}

SELECT
    name AS term_name,
    guid,
    userdescription AS description,
    certificatestatus AS status,
    createdby AS created_by,
    anchor AS glossary_guids,
    categories AS category_guids
FROM ${termTable}
WHERE name ILIKE '%${termName}%'
   OR userdescription ILIKE '%${termName}%'
ORDER BY name
LIMIT ${rowLimit};
`.trim();

  return {
    title: `📖 Glossary: ${termName}`,
    description: `Glossary terms matching "${termName}".`,
    sql,
    database: entity.database || 'FIELD_METADATA',
    schema: entity.schema || 'PUBLIC',
    timeoutSeconds: 30,
    limit: rowLimit,
    flowType: 'GLOSSARY_LOOKUP',
    entity,
  };
}

/**
 * Build a query to find assets linked to a glossary term
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildTermLinkedAssetsQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 200 } = inputs;
  const termGuid = entity.guid || '<TERM_GUID>';
  const termName = entity.name || '<TERM>';
  
  // Check for table entity
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const hasTableEntity = tables.includes('TABLE_ENTITY');
  const hasColumnEntity = tables.includes('COLUMN_ENTITY');
  
  if (!hasTableEntity) {
    return {
      title: `🔗 Assets for: ${termName}`,
      description: 'TABLE_ENTITY not found.',
      sql: `-- TABLE_ENTITY not available\nSHOW TABLES;`,
      flowType: 'GLOSSARY_LOOKUP',
      entity,
    };
  }

  // MDLH stores term links in the MEANINGS array on assets
  const sql = `
-- Assets linked to glossary term: ${termName}
-- Term GUID: ${termGuid}

SELECT
    'TABLE' AS asset_type,
    t.name AS asset_name,
    t.guid AS asset_guid,
    t.databasename,
    t.schemaname,
    t.meanings
FROM TABLE_ENTITY t
WHERE ARRAY_CONTAINS('${termGuid}'::VARIANT, t.meanings)
${hasColumnEntity ? `
UNION ALL

SELECT
    'COLUMN' AS asset_type,
    c.name AS asset_name,
    c.guid AS asset_guid,
    c.databasename,
    c.schemaname,
    c.meanings
FROM COLUMN_ENTITY c
WHERE ARRAY_CONTAINS('${termGuid}'::VARIANT, c.meanings)
` : ''}
ORDER BY asset_type, asset_name
LIMIT ${rowLimit};
`.trim();

  return {
    title: `🔗 Assets linked to: ${termName}`,
    description: `Tables and columns linked to glossary term "${termName}".`,
    sql,
    database: entity.database || 'FIELD_METADATA',
    schema: entity.schema || 'PUBLIC',
    timeoutSeconds: 30,
    flowType: 'GLOSSARY_LOOKUP',
    entity,
  };
}

/**
 * Build a query to list all glossaries
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildListGlossariesQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 100 } = inputs;
  
  const tables = (availableTables || []).map(t => t.toUpperCase());
  const glossaryTable = tables.includes('ATLASGLOSSARY_ENTITY')
    ? 'ATLASGLOSSARY_ENTITY'
    : tables.find(t => t.includes('GLOSSARY') && !t.includes('TERM') && !t.includes('CATEGORY'));
  
  if (!glossaryTable) {
    return {
      title: '📚 All Glossaries',
      description: 'No glossary table found.',
      sql: `-- No ATLASGLOSSARY_ENTITY found\nSHOW TABLES LIKE '%GLOSSARY%';`,
      flowType: 'GLOSSARY_LOOKUP',
      entity,
    };
  }

  const sql = `
-- List all glossaries

SELECT
    name AS glossary_name,
    guid,
    userdescription AS description,
    createdby AS created_by,
    TO_TIMESTAMP(createtime/1000) AS created_at
FROM ${glossaryTable}
ORDER BY name
LIMIT ${rowLimit};
`.trim();

  return {
    title: '📚 All Glossaries',
    description: 'List of all business glossaries.',
    sql,
    database: entity.database || 'FIELD_METADATA',
    schema: entity.schema || 'PUBLIC',
    timeoutSeconds: 30,
    flowType: 'GLOSSARY_LOOKUP',
    entity,
  };
}

export default buildGlossaryQuery;

