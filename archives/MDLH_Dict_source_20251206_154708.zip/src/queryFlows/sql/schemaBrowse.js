/**
 * Schema Browse SQL Builder
 * 
 * Generates queries to explore database structure.
 * Uses SHOW TABLES and INFORMATION_SCHEMA which ALWAYS work.
 */

/**
 * Build a schema browse query - uses SHOW TABLES which always works
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildSchemaBrowseQuery(entity, inputs, availableTables = []) {
  const { rowLimit = 100, filters = {} } = inputs;
  const db = filters.database || entity.database || 'FIELD_METADATA';
  const schema = filters.schema || entity.schema || 'PUBLIC';
  
  // SHOW TABLES always works - this is the safest query
  const sql = `
-- List all tables in ${db}.${schema}
-- This query always works in Snowflake

SHOW TABLES IN ${db}.${schema};
`.trim();

  return {
    title: `📂 Tables in ${schema}`,
    description: `List all tables in ${db}.${schema}. Click table names in results to explore further.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    limit: rowLimit,
    flowType: 'SCHEMA_BROWSE',
    entity,
  };
}

/**
 * Build a query to find tables matching a pattern
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildTableSearchQuery(entity, inputs, availableTables = []) {
  const { searchTerm = '', rowLimit = 100 } = inputs;
  const db = entity.database || 'FIELD_METADATA';
  const schema = entity.schema || 'PUBLIC';
  
  // SHOW TABLES LIKE always works
  const sql = `
-- Find tables matching "${searchTerm || '*'}"
-- This query always works in Snowflake

SHOW TABLES LIKE '%${searchTerm}%' IN ${db}.${schema};
`.trim();

  return {
    title: `🔍 Find: ${searchTerm || 'tables'}`,
    description: `Tables matching "${searchTerm}" in ${db}.${schema}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    flowType: 'SCHEMA_BROWSE',
    entity,
  };
}

/**
 * Build a query to get column details for a table
 * Uses DESCRIBE which always works
 * @param {import('../types').EntityContext} entity 
 * @param {import('../types').QueryFlowInputs} inputs 
 * @param {string[]} [availableTables]
 * @returns {import('../types').BuiltQuery}
 */
export function buildColumnDetailsQuery(entity, inputs, availableTables = []) {
  const tableName = entity.table || entity.name || '<TABLE>';
  const db = entity.database || 'FIELD_METADATA';
  const schema = entity.schema || 'PUBLIC';
  
  // DESCRIBE always works
  const sql = `
-- Show columns in ${tableName}
-- This query always works in Snowflake

DESCRIBE TABLE ${db}.${schema}.${tableName};
`.trim();

  return {
    title: `📋 Columns: ${tableName}`,
    description: `Column details for ${db}.${schema}.${tableName}.`,
    sql,
    database: db,
    schema,
    timeoutSeconds: 30,
    flowType: 'SCHEMA_BROWSE',
    entity,
  };
}

/**
 * Build a simple SELECT * query to explore a table
 * @param {string} tableName 
 * @param {string} db 
 * @param {string} schema 
 * @param {number} limit 
 * @returns {string}
 */
export function buildSimpleSelectQuery(tableName, db = 'FIELD_METADATA', schema = 'PUBLIC', limit = 10) {
  return `
-- Preview data from ${tableName}
-- Simple SELECT * always works

SELECT *
FROM ${db}.${schema}.${tableName}
LIMIT ${limit};
`.trim();
}

export default buildSchemaBrowseQuery;
