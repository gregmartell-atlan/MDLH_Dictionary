/**
 * MDLH + Snowflake Query Library
 * 
 * Dual-layer query system:
 * - MDLH Layer: Atlan metadata (lineage, tags, glossary, ownership)
 * - Snowflake Layer: Platform reality (usage, structure, policies, costs)
 * 
 * Use {{PLACEHOLDERS}} for dynamic values that get filled from EntityContext
 */

// =============================================================================
// ENTITY CONTEXT TYPE
// =============================================================================

/**
 * @typedef {Object} EntityContext
 * @property {string} [database] - Snowflake database
 * @property {string} [schema] - Snowflake schema
 * @property {string} [table] - Table name
 * @property {string} [column] - Column name
 * @property {string} [guid] - Atlan GUID
 * @property {string} [qualifiedName] - Atlan qualified name
 * @property {string} [entityType] - TABLE | VIEW | COLUMN | PROCESS | TERM | DASHBOARD | MODEL | GLOSSARY
 * @property {string} [connectorName] - snowflake | databricks | tableau etc.
 * @property {number} [daysBack] - Time window for usage queries (default: 30)
 */

// =============================================================================
// TEMPLATE FILL HELPER
// =============================================================================

/**
 * Fill placeholders in SQL template with context values
 * @param {string} sqlTemplate - SQL with {{PLACEHOLDERS}}
 * @param {EntityContext} ctx - Entity context
 * @returns {string} Filled SQL
 */
export function fillTemplate(sqlTemplate, ctx) {
  return sqlTemplate
    .replace(/\{\{DATABASE\}\}/g, ctx.database || '<DATABASE>')
    .replace(/\{\{SCHEMA\}\}/g, ctx.schema || '<SCHEMA>')
    .replace(/\{\{TABLE\}\}/g, ctx.table || '<TABLE>')
    .replace(/\{\{COLUMN\}\}/g, ctx.column || '<COLUMN>')
    .replace(/\{\{GUID\}\}/g, ctx.guid || '<GUID>')
    .replace(/\{\{QUALIFIED_NAME\}\}/g, ctx.qualifiedName || '<QUALIFIED_NAME>')
    .replace(/\{\{DAYS_BACK\}\}/g, String(ctx.daysBack || 30))
    .replace(/\{\{OWNER_USERNAME\}\}/g, ctx.ownerUsername || '<OWNER>')
    .replace(/\{\{TERM_GUID\}\}/g, ctx.termGuid || '<TERM_GUID>')
    .replace(/\{\{GLOSSARY_GUID\}\}/g, ctx.glossaryGuid || '<GLOSSARY_GUID>');
}

// =============================================================================
// QUERY LAYERS
// =============================================================================

export const QUERY_LAYERS = {
  MDLH: 'mdlh',
  SNOWFLAKE: 'snowflake',
};

export const QUERY_CATEGORIES = {
  STRUCTURE: 'structure',
  LINEAGE: 'lineage',
  GOVERNANCE: 'governance',
  USAGE: 'usage',
  QUALITY: 'quality',
  GLOSSARY: 'glossary',
  COST: 'cost',
};

// =============================================================================
// PART 1: MDLH QUERIES (Atlan Metadata Layer)
// =============================================================================

export const MDLH_QUERIES = {
  // ---------------------------------------------------------------------------
  // Category A: Asset Discovery & Structure
  // ---------------------------------------------------------------------------
  
  entity_types_overview: {
    id: 'mdlh_entity_types_overview',
    label: 'Entity Types Overview',
    description: 'All MDLH entity types with row counts and sizes',
    category: QUERY_CATEGORIES.STRUCTURE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Database',
    requires: [],
    sql: `-- All available MDLH entity types and their volume
SELECT 
  table_name AS entity_type,
  row_count,
  ROUND(bytes / 1024 / 1024, 2) AS size_mb
FROM INFORMATION_SCHEMA.TABLES
WHERE table_schema = 'PUBLIC'
  AND table_type = 'BASE TABLE'
ORDER BY row_count DESC;`,
  },

  table_asset_details: {
    id: 'mdlh_table_asset_details',
    label: 'Asset Details (Atlan)',
    description: 'Full Atlan metadata for this table',
    category: QUERY_CATEGORIES.STRUCTURE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'FileText',
    requires: ['database', 'schema', 'table'],
    sql: `-- Atlan metadata for table
SELECT * 
FROM TABLE_ENTITY 
WHERE QUALIFIEDNAME LIKE '%{{DATABASE}}.{{SCHEMA}}.{{TABLE}}%'
LIMIT 10;`,
  },

  column_metadata_comprehensive: {
    id: 'mdlh_column_metadata',
    label: 'Column Metadata + Tags',
    description: 'Columns with custom metadata and classification tags',
    category: QUERY_CATEGORIES.STRUCTURE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Columns',
    requires: [],
    sql: `-- Column metadata with custom metadata and tags
WITH FILTERED_COLUMNS AS (
    SELECT GUID
    FROM COLUMN_ENTITY
    WHERE CONNECTORNAME IN ('glue', 'snowflake')
),
CM_AGG AS (
    SELECT
        CM.ENTITYGUID,
        ARRAY_AGG(DISTINCT OBJECT_CONSTRUCT(
            'set_name', SETDISPLAYNAME,
            'field_name', ATTRIBUTEDISPLAYNAME,
            'field_value', ATTRIBUTEVALUE
        )) AS CUSTOM_METADATA_JSON
    FROM CUSTOMMETADATA_RELATIONSHIP CM
    JOIN FILTERED_COLUMNS FC ON CM.ENTITYGUID = FC.GUID
    GROUP BY CM.ENTITYGUID
),
TR_AGG AS (
    SELECT
        TR.ENTITYGUID,
        '[' || LISTAGG(
            OBJECT_CONSTRUCT('name', TR.TAGNAME, 'value', TR.TAGVALUE)::STRING, ','
        ) WITHIN GROUP (ORDER BY TR.TAGNAME) || ']' AS TAG_JSON
    FROM TAG_RELATIONSHIP TR
    JOIN FILTERED_COLUMNS FC ON TR.ENTITYGUID = FC.GUID
    GROUP BY TR.ENTITYGUID
)
SELECT
    COL.NAME, COL.QUALIFIEDNAME, COL.GUID, COL.DISPLAYNAME,
    COL.DESCRIPTION, COL.USERDESCRIPTION, COL.CONNECTORNAME,
    COL.CONNECTIONNAME, COL.DATABASENAME, COL.SCHEMANAME,
    COL.TABLENAME, COL.TYPENAME, COL.DATATYPE,
    TR_AGG.TAG_JSON,
    CM_AGG.CUSTOM_METADATA_JSON,
    COL.CERTIFICATESTATUS, COL.OWNERUSERS, COL.OWNERGROUPS,
    COL.ISPROFILED, COL.COLUMNDISTINCTVALUESCOUNT,
    COL.COLUMNMAX, COL.COLUMNMIN, COL.COLUMNMEAN
FROM COLUMN_ENTITY COL
LEFT JOIN CM_AGG ON COL.GUID = CM_AGG.ENTITYGUID
LEFT JOIN TR_AGG ON COL.GUID = TR_AGG.ENTITYGUID
WHERE COL.CONNECTORNAME IN ('glue', 'snowflake')
LIMIT 100;`,
  },

  // ---------------------------------------------------------------------------
  // Category B: Lineage Analysis
  // ---------------------------------------------------------------------------

  upstream_direct: {
    id: 'mdlh_upstream',
    label: 'Upstream Lineage (1 hop)',
    description: 'Direct upstream assets feeding this entity',
    category: QUERY_CATEGORIES.LINEAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'ArrowUpLeft',
    requires: ['guid'],
    sql: `-- Direct upstream assets (1 hop)
SELECT 
    P.GUID AS process_guid,
    P.NAME AS process_name,
    ARRAY_TO_STRING(P.INPUTS, ', ') AS upstream_assets,
    ARRAY_TO_STRING(P.OUTPUTS, ', ') AS downstream_assets
FROM PROCESS_ENTITY P
WHERE ARRAY_CONTAINS('{{GUID}}'::VARIANT, P.OUTPUTS)
LIMIT 50;`,
  },

  downstream_direct: {
    id: 'mdlh_downstream',
    label: 'Downstream Lineage (1 hop)',
    description: 'Direct downstream assets consuming this entity',
    category: QUERY_CATEGORIES.LINEAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'ArrowDownRight',
    requires: ['guid'],
    sql: `-- Direct downstream assets (1 hop)
SELECT 
    P.GUID AS process_guid,
    P.NAME AS process_name,
    ARRAY_TO_STRING(P.INPUTS, ', ') AS upstream_assets,
    ARRAY_TO_STRING(P.OUTPUTS, ', ') AS downstream_assets
FROM PROCESS_ENTITY P
WHERE ARRAY_CONTAINS('{{GUID}}'::VARIANT, P.INPUTS)
LIMIT 50;`,
  },

  lineage_chain_recursive: {
    id: 'mdlh_lineage_chain',
    label: 'Full Lineage Chain',
    description: 'Recursive upstream lineage up to 5 hops',
    category: QUERY_CATEGORIES.LINEAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'GitBranch',
    requires: ['guid'],
    sql: `-- Full lineage chain (recursive CTE, up to 5 hops)
WITH RECURSIVE lineage_chain AS (
    -- Base: direct upstream
    SELECT 
        P.GUID AS process_guid,
        INPUT.VALUE::STRING AS asset_guid,
        1 AS hop_level,
        'UPSTREAM' AS direction
    FROM PROCESS_ENTITY P,
         LATERAL FLATTEN(P.INPUTS) INPUT
    WHERE ARRAY_CONTAINS('{{GUID}}'::VARIANT, P.OUTPUTS)
    
    UNION ALL
    
    -- Recursive: follow upstream
    SELECT 
        P.GUID,
        INPUT.VALUE::STRING,
        lc.hop_level + 1,
        'UPSTREAM'
    FROM lineage_chain lc
    JOIN PROCESS_ENTITY P ON ARRAY_CONTAINS(lc.asset_guid::VARIANT, P.OUTPUTS)
    CROSS JOIN LATERAL FLATTEN(P.INPUTS) INPUT
    WHERE lc.hop_level < 5  -- depth limit
)
SELECT DISTINCT
    asset_guid,
    hop_level,
    direction,
    T.NAME AS asset_name,
    T.TYPENAME AS asset_type
FROM lineage_chain lc
LEFT JOIN TABLE_ENTITY T ON lc.asset_guid = T.GUID
ORDER BY hop_level, asset_name;`,
  },

  impact_dashboards: {
    id: 'mdlh_impact_dashboards',
    label: 'Impacted Dashboards',
    description: 'Downstream dashboards that depend on this asset',
    category: QUERY_CATEGORIES.LINEAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'LayoutDashboard',
    requires: ['guid'],
    sql: `-- Impact analysis - downstream dashboards
WITH downstream AS (
    SELECT 
        OUTPUT.VALUE::STRING AS downstream_guid
    FROM PROCESS_ENTITY P,
         LATERAL FLATTEN(P.OUTPUTS) OUTPUT
    WHERE ARRAY_CONTAINS('{{GUID}}'::VARIANT, P.INPUTS)
)
SELECT 
    D.GUID,
    D.NAME,
    D.TYPENAME,
    D.CONNECTIONNAME
FROM downstream ds
JOIN TABLEAUDASHBOARD_ENTITY D ON ds.downstream_guid = D.GUID

UNION ALL

SELECT 
    D.GUID,
    D.NAME,
    D.TYPENAME,
    D.CONNECTIONNAME
FROM downstream ds
JOIN POWERBIDASHBOARD_ENTITY D ON ds.downstream_guid = D.GUID;`,
  },

  // ---------------------------------------------------------------------------
  // Category C: Governance & Compliance
  // ---------------------------------------------------------------------------

  tags_for_asset: {
    id: 'mdlh_tags',
    label: 'Atlan Tags',
    description: 'Classification tags applied to this asset',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Tag',
    requires: ['guid'],
    sql: `-- Tags applied to asset
SELECT
    TR.ENTITYGUID,
    TR.ENTITYTYPENAME,
    TR.TAGNAME,
    TR.TAGVALUE,
    TR.PROPAGATE,
    TR.PROPAGATEFROMLINEAGE
FROM TAG_RELATIONSHIP TR
WHERE TR.ENTITYGUID = '{{GUID}}';`,
  },

  tables_without_tags: {
    id: 'mdlh_untagged_tables',
    label: 'Untagged Tables (Compliance Gap)',
    description: 'Tables missing classification tags',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'AlertTriangle',
    requires: [],
    sql: `-- Tables WITHOUT tags (compliance gap)
SELECT DISTINCT
    TB.GUID,
    TB.NAME AS table_name,
    TB.CREATEDBY,
    TB.DATABASEQUALIFIEDNAME
FROM TABLE_ENTITY TB
LEFT JOIN TAG_RELATIONSHIP TG ON TB.GUID = TG.ENTITYGUID
WHERE TG.TAGNAME IS NULL
  AND TB.STATUS = 'ACTIVE'
LIMIT 100;`,
  },

  pii_sensitive_discovery: {
    id: 'mdlh_pii_discovery',
    label: 'PII/Sensitive Data',
    description: 'Assets tagged as PII, Confidential, or Sensitive',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Shield',
    requires: [],
    sql: `-- PII/Sensitive data discovery
SELECT
    TR.ENTITYGUID,
    TE.NAME AS entity_name,
    TE.QUALIFIEDNAME,
    TR.TAGNAME,
    TR.TAGVALUE
FROM TAG_RELATIONSHIP TR
JOIN TABLE_ENTITY TE ON TR.ENTITYGUID = TE.GUID
WHERE TR.TAGNAME IN ('PII', 'Confidential', 'Sensitive', 'PHI')
ORDER BY TR.TAGNAME, TE.NAME
LIMIT 100;`,
  },

  assets_by_owner: {
    id: 'mdlh_by_owner',
    label: 'Assets by Owner',
    description: 'All assets owned by a specific user',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'User',
    requires: ['ownerUsername'],
    sql: `-- Assets by owner
SELECT
    NAME,
    TYPENAME,
    QUALIFIEDNAME,
    OWNERUSERS,
    OWNERGROUPS,
    CERTIFICATESTATUS
FROM TABLE_ENTITY
WHERE ARRAY_CONTAINS('{{OWNER_USERNAME}}'::VARIANT, OWNERUSERS)
ORDER BY TYPENAME, NAME
LIMIT 100;`,
  },

  // ---------------------------------------------------------------------------
  // Category D: Glossary & Business Context
  // ---------------------------------------------------------------------------

  all_glossaries: {
    id: 'mdlh_glossaries',
    label: 'All Glossaries',
    description: 'List all business glossaries',
    category: QUERY_CATEGORIES.GLOSSARY,
    layer: QUERY_LAYERS.MDLH,
    icon: 'BookOpen',
    requires: [],
    sql: `-- All glossaries
SELECT
    NAME,
    GUID,
    CREATEDBY,
    USERDESCRIPTION
FROM ATLASGLOSSARY_ENTITY
ORDER BY NAME;`,
  },

  terms_in_glossary: {
    id: 'mdlh_glossary_terms',
    label: 'Terms in Glossary',
    description: 'All terms in a specific glossary',
    category: QUERY_CATEGORIES.GLOSSARY,
    layer: QUERY_LAYERS.MDLH,
    icon: 'List',
    requires: ['glossaryGuid'],
    sql: `-- Terms in a glossary
SELECT
    GUID,
    NAME,
    USERDESCRIPTION,
    CERTIFICATESTATUS
FROM ATLASGLOSSARYTERM_ENTITY
WHERE ARRAY_CONTAINS('{{GLOSSARY_GUID}}'::VARIANT, ANCHOR)
ORDER BY NAME;`,
  },

  assets_linked_to_term: {
    id: 'mdlh_term_assets',
    label: 'Assets Linked to Term',
    description: 'Tables and columns linked to a glossary term',
    category: QUERY_CATEGORIES.GLOSSARY,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Link',
    requires: ['termGuid'],
    sql: `-- Assets linked to a glossary term
SELECT
    T.GUID,
    T.NAME,
    T.TYPENAME,
    T.QUALIFIEDNAME
FROM TABLE_ENTITY T
WHERE ARRAY_CONTAINS('{{TERM_GUID}}'::VARIANT, T.MEANINGS)

UNION ALL

SELECT
    C.GUID,
    C.NAME,
    C.TYPENAME,
    C.QUALIFIEDNAME
FROM COLUMN_ENTITY C
WHERE ARRAY_CONTAINS('{{TERM_GUID}}'::VARIANT, C.MEANINGS);`,
  },

  duplicate_terms: {
    id: 'mdlh_duplicate_terms',
    label: 'Duplicate Terms',
    description: 'Detect glossary terms with similar names',
    category: QUERY_CATEGORIES.GLOSSARY,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Copy',
    requires: [],
    sql: `-- Duplicate glossary term detection
SELECT
    LOWER(NAME) AS normalized_name,
    COUNT(*) AS term_count,
    ARRAY_AGG(GUID) AS guids,
    ARRAY_AGG(NAME) AS original_names
FROM ATLASGLOSSARYTERM_ENTITY
GROUP BY LOWER(NAME)
HAVING COUNT(*) > 1
ORDER BY term_count DESC;`,
  },

  // ---------------------------------------------------------------------------
  // Category E: Usage & Popularity
  // ---------------------------------------------------------------------------

  most_active_users: {
    id: 'mdlh_active_users',
    label: 'Most Active Users',
    description: 'Users who updated the most assets',
    category: QUERY_CATEGORIES.USAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Users',
    requires: [],
    sql: `-- Most active users (by updates)
SELECT
    UPDATEDBY,
    TO_TIMESTAMP(MAX(UPDATETIME)/1000) AS last_update,
    COUNT(*) AS update_count
FROM COLUMN_ENTITY
GROUP BY UPDATEDBY
ORDER BY update_count DESC
LIMIT 20;`,
  },

  most_popular_tables: {
    id: 'mdlh_popular_tables',
    label: 'Most Popular Tables',
    description: 'Tables ranked by Atlan popularity score',
    category: QUERY_CATEGORIES.USAGE,
    layer: QUERY_LAYERS.MDLH,
    icon: 'TrendingUp',
    requires: [],
    sql: `-- Most popular tables (by popularity score)
SELECT
    NAME,
    QUALIFIEDNAME,
    POPULARITYSCORE,
    ROWCOUNT,
    SIZEBYTES / 1024 / 1024 AS size_mb
FROM TABLE_ENTITY
WHERE POPULARITYSCORE IS NOT NULL
ORDER BY POPULARITYSCORE DESC
LIMIT 50;`,
  },

  large_unused_tables: {
    id: 'mdlh_unused_tables',
    label: 'Large Unused Tables',
    description: 'Big tables with low popularity (cost optimization)',
    category: QUERY_CATEGORIES.COST,
    layer: QUERY_LAYERS.MDLH,
    icon: 'Trash2',
    requires: [],
    sql: `-- Large unused tables (cost optimization)
SELECT
    NAME,
    QUALIFIEDNAME,
    ROWCOUNT,
    SIZEBYTES / 1024 / 1024 AS size_mb,
    POPULARITYSCORE
FROM TABLE_ENTITY
WHERE SIZEBYTES IS NOT NULL
  AND (POPULARITYSCORE IS NULL OR POPULARITYSCORE < 0.1)
ORDER BY SIZEBYTES DESC
LIMIT 50;`,
  },
};

// =============================================================================
// PART 2: SNOWFLAKE SYSTEM QUERIES (Platform Reality Layer)
// =============================================================================

export const SNOWFLAKE_QUERIES = {
  // ---------------------------------------------------------------------------
  // Bundle A: Structure & Stats
  // ---------------------------------------------------------------------------

  columns_live: {
    id: 'sf_columns',
    label: 'Column Structure (Live)',
    description: 'Real-time column structure from Snowflake',
    category: QUERY_CATEGORIES.STRUCTURE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Columns',
    requires: ['database', 'schema', 'table'],
    sql: `-- Live column structure from Snowflake
SELECT
    column_name,
    data_type,
    is_nullable,
    comment
FROM {{DATABASE}}.information_schema.columns
WHERE table_schema = '{{SCHEMA}}'
  AND table_name = '{{TABLE}}'
ORDER BY ordinal_position;`,
  },

  table_size_rows: {
    id: 'sf_table_size',
    label: 'Table Size & Rows',
    description: 'Storage size, row count, and last altered time',
    category: QUERY_CATEGORIES.STRUCTURE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'HardDrive',
    requires: ['database', 'schema', 'table'],
    sql: `-- Table size, rows, and last altered
SELECT
    t.table_name,
    t.row_count,
    t.bytes / 1024 / 1024 AS size_mb,
    t.retention_time,
    t.last_altered
FROM {{DATABASE}}.information_schema.tables t
WHERE t.table_schema = '{{SCHEMA}}'
  AND t.table_name = '{{TABLE}}';`,
  },

  data_freshness: {
    id: 'sf_freshness',
    label: 'Data Freshness',
    description: 'Most recent timestamp in the table',
    category: QUERY_CATEGORIES.QUALITY,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Clock',
    requires: ['database', 'schema', 'table'],
    sql: `-- Data freshness (replace UPDATED_AT with actual timestamp column)
-- SELECT MAX("UPDATED_AT") AS last_update_at
-- FROM {{DATABASE}}.{{SCHEMA}}.{{TABLE}};

-- Alternative: check table metadata
SELECT 
    table_name,
    last_altered,
    DATEDIFF('hour', last_altered, CURRENT_TIMESTAMP()) AS hours_since_update
FROM {{DATABASE}}.information_schema.tables
WHERE table_schema = '{{SCHEMA}}'
  AND table_name = '{{TABLE}}';`,
  },

  // ---------------------------------------------------------------------------
  // Bundle B: Usage & Query History
  // ---------------------------------------------------------------------------

  top_users: {
    id: 'sf_top_users',
    label: 'Top Users (30d)',
    description: 'Users who query this table most frequently',
    category: QUERY_CATEGORIES.USAGE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Users',
    requires: ['database', 'schema', 'table'],
    sql: `-- Top users hitting this table (last {{DAYS_BACK}} days)
WITH table_access AS (
    SELECT
        q.query_id,
        q.user_name,
        q.role_name,
        q.start_time,
        q.total_elapsed_time,
        q.rows_produced
    FROM snowflake.account_usage.query_history q
    WHERE q.start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
      AND POSITION('{{DATABASE}}.{{SCHEMA}}.{{TABLE}}' IN UPPER(q.query_text)) > 0
)
SELECT
    user_name,
    role_name,
    COUNT(*) AS query_count,
    SUM(total_elapsed_time) / 1000.0 AS total_seconds,
    SUM(rows_produced) AS total_rows_produced
FROM table_access
GROUP BY user_name, role_name
ORDER BY query_count DESC
LIMIT 20;`,
  },

  expensive_queries: {
    id: 'sf_expensive_queries',
    label: 'Expensive Queries',
    description: 'Most costly queries by bytes scanned',
    category: QUERY_CATEGORIES.COST,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'DollarSign',
    requires: ['database', 'schema', 'table'],
    sql: `-- Most expensive queries (by bytes scanned)
SELECT
    q.query_id,
    q.user_name,
    q.start_time,
    q.total_elapsed_time / 1000.0 AS duration_seconds,
    q.bytes_scanned / 1024 / 1024 / 1024 AS gb_scanned,
    LEFT(q.query_text, 200) AS query_preview
FROM snowflake.account_usage.query_history q
WHERE q.start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
  AND POSITION('{{DATABASE}}.{{SCHEMA}}.{{TABLE}}' IN UPPER(q.query_text)) > 0
ORDER BY q.bytes_scanned DESC
LIMIT 20;`,
  },

  access_history: {
    id: 'sf_access_history',
    label: 'Access History',
    description: 'Recent access events for this table',
    category: QUERY_CATEGORIES.USAGE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Activity',
    requires: ['database', 'schema', 'table'],
    sql: `-- Access history (downstream objects reading this table)
SELECT
    ah.query_id,
    ah.user_name,
    ah.query_start_time,
    boa.value:"objectName"::string AS accessed_object
FROM snowflake.account_usage.access_history ah,
     LATERAL FLATTEN(ah.base_objects_accessed) AS boa
WHERE boa.value:"objectDomain"::string = 'Table'
  AND UPPER(boa.value:"objectName"::string) = '{{DATABASE}}.{{SCHEMA}}.{{TABLE}}'
  AND ah.query_start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
ORDER BY ah.query_start_time DESC
LIMIT 100;`,
  },

  // ---------------------------------------------------------------------------
  // Bundle C: Tags & Policies
  // ---------------------------------------------------------------------------

  native_tags: {
    id: 'sf_native_tags',
    label: 'Snowflake Tags',
    description: 'Native Snowflake tags on table and columns',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Tag',
    requires: ['database', 'schema', 'table'],
    sql: `-- Native Snowflake tags on table & columns
SELECT
    object_database,
    object_schema,
    object_name,
    column_name,
    tag_database,
    tag_schema,
    tag_name,
    tag_value
FROM {{DATABASE}}.information_schema.tag_references_all_columns
WHERE object_schema = '{{SCHEMA}}'
  AND object_name = '{{TABLE}}'
ORDER BY column_name, tag_name;`,
  },

  masking_policies: {
    id: 'sf_policies',
    label: 'Masking Policies',
    description: 'Data masking and row access policies',
    category: QUERY_CATEGORIES.GOVERNANCE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Eye',
    requires: ['database', 'schema', 'table'],
    sql: `-- Masking & row access policies
SELECT
    policy_name,
    policy_kind,
    policy_status,
    policy_body,
    ref_column_name
FROM {{DATABASE}}.information_schema.policy_references
WHERE ref_database = '{{DATABASE}}'
  AND ref_schema = '{{SCHEMA}}'
  AND ref_entity_name = '{{TABLE}}'
ORDER BY policy_name;`,
  },

  // ---------------------------------------------------------------------------
  // Bundle D: Data Quality & Profiling
  // ---------------------------------------------------------------------------

  null_stats: {
    id: 'sf_null_stats',
    label: 'Null Analysis',
    description: 'Null counts and distinct values for a column',
    category: QUERY_CATEGORIES.QUALITY,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Circle',
    requires: ['database', 'schema', 'table', 'column'],
    sql: `-- Column null & distinct stats
SELECT
    COUNT(*) AS total_rows,
    COUNT(*) - COUNT({{COLUMN}}) AS null_count,
    ROUND((COUNT(*) - COUNT({{COLUMN}}))::FLOAT / NULLIF(COUNT(*), 0) * 100, 2) AS null_pct,
    COUNT(DISTINCT {{COLUMN}}) AS distinct_values
FROM {{DATABASE}}.{{SCHEMA}}.{{TABLE}};`,
  },

  top_values: {
    id: 'sf_top_values',
    label: 'Top Values',
    description: 'Most frequent values in a column',
    category: QUERY_CATEGORIES.QUALITY,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'BarChart2',
    requires: ['database', 'schema', 'table', 'column'],
    sql: `-- Top values for a column
SELECT
    {{COLUMN}} AS value,
    COUNT(*) AS freq,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) AS pct
FROM {{DATABASE}}.{{SCHEMA}}.{{TABLE}}
GROUP BY {{COLUMN}}
ORDER BY freq DESC
LIMIT 50;`,
  },

  numeric_stats: {
    id: 'sf_numeric_stats',
    label: 'Numeric Stats',
    description: 'Min, max, avg, median, stddev for numeric column',
    category: QUERY_CATEGORIES.QUALITY,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'Hash',
    requires: ['database', 'schema', 'table', 'column'],
    sql: `-- Numeric column statistics
SELECT
    MIN({{COLUMN}}) AS min_value,
    MAX({{COLUMN}}) AS max_value,
    AVG({{COLUMN}}) AS avg_value,
    MEDIAN({{COLUMN}}) AS median_value,
    STDDEV({{COLUMN}}) AS stddev_value
FROM {{DATABASE}}.{{SCHEMA}}.{{TABLE}};`,
  },

  // ---------------------------------------------------------------------------
  // Bundle E: Platform / Account-Level
  // ---------------------------------------------------------------------------

  warehouse_costs: {
    id: 'sf_warehouse_costs',
    label: 'Warehouse Costs (30d)',
    description: 'Credit usage by warehouse',
    category: QUERY_CATEGORIES.COST,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'DollarSign',
    requires: [],
    sql: `-- Top warehouses by cost (last {{DAYS_BACK}} days)
SELECT
    warehouse_name,
    COUNT(*) AS query_count,
    SUM(credits_used_cloud_services) AS credits_cloud,
    SUM(credits_used_compute) AS credits_compute,
    SUM(credits_used_cloud_services + credits_used_compute) AS total_credits
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
GROUP BY warehouse_name
ORDER BY total_credits DESC
LIMIT 20;`,
  },

  most_accessed_tables: {
    id: 'sf_most_accessed',
    label: 'Most Accessed Tables',
    description: 'Tables with highest access frequency account-wide',
    category: QUERY_CATEGORIES.USAGE,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'TrendingUp',
    requires: [],
    sql: `-- Most accessed tables account-wide
WITH accessed AS (
    SELECT
        boa.value:"objectName"::string AS table_name,
        ah.user_name,
        ah.query_start_time
    FROM snowflake.account_usage.access_history ah,
         LATERAL FLATTEN(ah.base_objects_accessed) boa
    WHERE boa.value:"objectDomain"::string = 'Table'
      AND ah.query_start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
)
SELECT
    table_name,
    COUNT(*) AS access_events,
    COUNT(DISTINCT user_name) AS distinct_users
FROM accessed
GROUP BY table_name
ORDER BY access_events DESC
LIMIT 100;`,
  },

  failed_queries: {
    id: 'sf_failed_queries',
    label: 'Failed Queries',
    description: 'Common query errors and affected users',
    category: QUERY_CATEGORIES.QUALITY,
    layer: QUERY_LAYERS.SNOWFLAKE,
    icon: 'XCircle',
    requires: [],
    sql: `-- Failed queries (error analysis)
SELECT
    error_code,
    error_message,
    COUNT(*) AS error_count,
    COUNT(DISTINCT user_name) AS affected_users
FROM snowflake.account_usage.query_history
WHERE start_time >= DATEADD(day, -{{DAYS_BACK}}, CURRENT_TIMESTAMP())
  AND error_code IS NOT NULL
GROUP BY error_code, error_message
ORDER BY error_count DESC
LIMIT 20;`,
  },
};

// =============================================================================
// COMBINED QUERY REGISTRY
// =============================================================================

export const ALL_QUERIES = {
  ...MDLH_QUERIES,
  ...SNOWFLAKE_QUERIES,
};

// =============================================================================
// QUERY RECOMMENDATION ENGINE
// =============================================================================

/**
 * Get recommended queries based on entity context
 * @param {EntityContext} ctx - Entity context
 * @returns {Array<{query: object, priority: number}>} Sorted query recommendations
 */
export function getRecommendedQueries(ctx) {
  const recommendations = [];

  // Table-level queries
  if (ctx.table && ['TABLE', 'VIEW', 'MATERIALIZED_VIEW'].includes(ctx.entityType)) {
    // MDLH layer - structure & lineage
    recommendations.push(
      { query: MDLH_QUERIES.table_asset_details, priority: 1 },
      { query: MDLH_QUERIES.upstream_direct, priority: 2 },
      { query: MDLH_QUERIES.downstream_direct, priority: 2 },
      { query: MDLH_QUERIES.tags_for_asset, priority: 3 },
      { query: MDLH_QUERIES.impact_dashboards, priority: 4 },
    );
    
    // Snowflake layer - live data
    recommendations.push(
      { query: SNOWFLAKE_QUERIES.columns_live, priority: 1 },
      { query: SNOWFLAKE_QUERIES.table_size_rows, priority: 1 },
      { query: SNOWFLAKE_QUERIES.top_users, priority: 2 },
      { query: SNOWFLAKE_QUERIES.native_tags, priority: 3 },
      { query: SNOWFLAKE_QUERIES.masking_policies, priority: 3 },
      { query: SNOWFLAKE_QUERIES.expensive_queries, priority: 4 },
    );
  }

  // Column-level queries
  if (ctx.column) {
    recommendations.push(
      { query: SNOWFLAKE_QUERIES.null_stats, priority: 1 },
      { query: SNOWFLAKE_QUERIES.top_values, priority: 1 },
      { query: SNOWFLAKE_QUERIES.numeric_stats, priority: 2 },
    );
  }

  // Process/Lineage entities
  if (ctx.entityType === 'PROCESS') {
    recommendations.push(
      { query: MDLH_QUERIES.upstream_direct, priority: 1 },
      { query: MDLH_QUERIES.downstream_direct, priority: 1 },
      { query: MDLH_QUERIES.lineage_chain_recursive, priority: 2 },
    );
  }

  // Glossary entities
  if (ctx.entityType === 'GLOSSARY') {
    recommendations.push(
      { query: MDLH_QUERIES.all_glossaries, priority: 1 },
      { query: MDLH_QUERIES.terms_in_glossary, priority: 2 },
    );
  }

  if (ctx.entityType === 'TERM') {
    recommendations.push(
      { query: MDLH_QUERIES.assets_linked_to_term, priority: 1 },
    );
  }

  // Always available queries (no specific context needed)
  if (!ctx.table && !ctx.column) {
    recommendations.push(
      { query: MDLH_QUERIES.entity_types_overview, priority: 1 },
      { query: MDLH_QUERIES.most_popular_tables, priority: 2 },
      { query: MDLH_QUERIES.large_unused_tables, priority: 3 },
      { query: SNOWFLAKE_QUERIES.warehouse_costs, priority: 2 },
      { query: SNOWFLAKE_QUERIES.most_accessed_tables, priority: 2 },
    );
  }

  // Sort by priority and remove duplicates
  return recommendations
    .sort((a, b) => a.priority - b.priority)
    .filter((item, index, self) => 
      index === self.findIndex(t => t.query.id === item.query.id)
    );
}

/**
 * Check if a query can be executed with the given context
 * @param {object} query - Query definition
 * @param {EntityContext} ctx - Entity context
 * @returns {boolean} True if all required context fields are available
 */
export function canExecuteQuery(query, ctx) {
  if (!query.requires || query.requires.length === 0) return true;
  return query.requires.every(field => ctx[field]);
}

/**
 * Get queries grouped by layer and category
 * @returns {object} Queries grouped by layer > category
 */
export function getQueriesByLayerAndCategory() {
  const grouped = {
    [QUERY_LAYERS.MDLH]: {},
    [QUERY_LAYERS.SNOWFLAKE]: {},
  };

  Object.values(ALL_QUERIES).forEach(query => {
    if (!grouped[query.layer][query.category]) {
      grouped[query.layer][query.category] = [];
    }
    grouped[query.layer][query.category].push(query);
  });

  return grouped;
}

export default {
  fillTemplate,
  QUERY_LAYERS,
  QUERY_CATEGORIES,
  MDLH_QUERIES,
  SNOWFLAKE_QUERIES,
  ALL_QUERIES,
  getRecommendedQueries,
  canExecuteQuery,
  getQueriesByLayerAndCategory,
};

