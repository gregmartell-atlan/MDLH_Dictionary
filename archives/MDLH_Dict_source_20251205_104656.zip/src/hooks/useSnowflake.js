/**
 * Snowflake hooks - React hooks for managing Snowflake operations
 * 
 * Updated to use session-based backend with X-Session-ID headers.
 * Includes fetch timeout support and improved error handling.
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import { createLogger } from '../utils/logger';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const SESSION_KEY = 'snowflake_session';
const DEFAULT_TIMEOUT_MS = 30000; // 30 seconds default timeout

// =============================================================================
// Scoped Loggers
// =============================================================================
const sessionLog = createLogger('Session');
const connectionLog = createLogger('useConnection');
const queryLog = createLogger('useQuery');
const metadataLog = createLogger('useMetadata');
const preflightLog = createLogger('usePreflight');
const historyLog = createLogger('useQueryHistory');
const explainLog = createLogger('useQueryExplanation');
const batchLog = createLogger('useBatchValidation');

// =============================================================================
// Shared Helpers (DRY)
// =============================================================================

/**
 * Get session ID from sessionStorage
 * @returns {string|null} Session ID or null
 */
function getSessionId() {
  const stored = sessionStorage.getItem(SESSION_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      sessionLog.debug('getSessionId()', {
        hasSession: !!parsed.sessionId,
        sessionPrefix: parsed.sessionId?.substring(0, 8),
        database: parsed.database,
        schema: parsed.schema
      });
      return parsed.sessionId;
    } catch (e) {
      sessionLog.error('getSessionId() parse error', { error: e.message });
      return null;
    }
  }
  sessionLog.debug('getSessionId() - no session in storage');
  return null;
}

/**
 * Fetch with timeout wrapper - prevents hanging requests
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options
 * @param {number} timeoutMs - Timeout in milliseconds (default: 30000)
 * @returns {Promise<Response>}
 */
async function fetchWithTimeout(url, options = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, { 
      ...options, 
      signal: controller.signal 
    });
    return response;
  } finally {
    clearTimeout(id);
  }
}

// =============================================================================
// Session Management Hook
// =============================================================================

export function useConnection() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const testConnectionRef = useRef(null);
  const testingInProgressRef = useRef(false); // Guard against double-calls

  // Get session from storage
  const getStoredSession = useCallback(() => {
    const storedRaw = sessionStorage.getItem(SESSION_KEY);
    connectionLog.debug('getStoredSession()', { 
      hasValue: !!storedRaw,
      preview: storedRaw ? `${storedRaw.substring(0, 50)}...` : 'NULL'
    });
    
    if (storedRaw) {
      try {
        const parsed = JSON.parse(storedRaw);
        connectionLog.debug('getStoredSession() - parsed', {
          hasSessionId: !!parsed.sessionId,
          sessionIdPrefix: parsed.sessionId?.substring(0, 8) || 'N/A',
          database: parsed.database || 'N/A',
          keys: Object.keys(parsed)
        });
        return parsed;
      } catch (e) {
        connectionLog.error('getStoredSession() - parse error, clearing key', { error: e.message });
        sessionStorage.removeItem(SESSION_KEY);
      }
    }
    return null;
  }, []);

  // Check if session is valid
  // FIX: Don't delete session on network errors - only on explicit 401/404
  const testConnection = useCallback(async () => {
    // Guard against double-calls (React StrictMode, rapid re-renders)
    if (testingInProgressRef.current) {
      connectionLog.debug('testConnection() already in progress - skipping');
      return status || { connected: false };
    }
    testingInProgressRef.current = true;

    connectionLog.info('testConnection() called');
    setLoading(true);
    setError(null);

    const stored = getStoredSession();
    
    if (!stored?.sessionId) {
      connectionLog.warn('testConnection() - no stored session, setting connected=false');
      setStatus({ connected: false });
      setLoading(false);
      testingInProgressRef.current = false;
      return { connected: false };
    }

    connectionLog.info('testConnection() - checking session with backend', {
      sessionIdPrefix: stored.sessionId.substring(0, 8),
      database: stored.database,
      schema: stored.schema
    });

    const endTimer = connectionLog.time('Backend session check');

    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/session/status`,
        { headers: { 'X-Session-ID': stored.sessionId } },
        5000 // 5s timeout
      );
      
      const durationMs = endTimer({ status: res.status, ok: res.ok });

      // Check for explicit "session invalid" responses
      if (res.status === 401 || res.status === 404) {
        connectionLog.warn('Session explicitly invalid (401/404) - removing from storage', { status: res.status });
        sessionStorage.removeItem(SESSION_KEY);
        setStatus({ connected: false });
        setLoading(false);
        testingInProgressRef.current = false;
        return { connected: false };
      }

      const data = await res.json();
      connectionLog.debug('Session status response', {
        valid: data.valid,
        user: data.user,
        database: data.database,
        durationMs
      });
      
      if (data.valid) {
        const sessionStatus = {
          connected: true,
          sessionId: stored.sessionId,
          user: data.user,
          warehouse: data.warehouse,
          database: data.database,
          schema: data.schema_name,
          role: data.role
        };
        setStatus(sessionStatus);
        setLoading(false);
        testingInProgressRef.current = false;
        connectionLog.info('Session VALID - connected', { database: data.database, user: data.user });
        return sessionStatus;
      } else {
        connectionLog.warn('Backend says session INVALID - removing from storage', { data });
        sessionStorage.removeItem(SESSION_KEY);
        setStatus({ connected: false });
        setLoading(false);
        testingInProgressRef.current = false;
        return { connected: false };
      }
    } catch (err) {
      // ⚠️ KEY FIX: Network error or timeout - DON'T delete the session!
      if (err.name === 'AbortError') {
        connectionLog.warn('Session check TIMED OUT - assuming session still valid', { 
          sessionIdPrefix: stored.sessionId.substring(0, 8) 
        });
      } else {
        connectionLog.warn('Session check NETWORK ERROR - assuming session still valid', {
          message: err.message,
          sessionIdPrefix: stored.sessionId.substring(0, 8)
        });
      }
      
      // Trust the stored session - let actual queries fail if it's really invalid
      const assumedSessionStatus = {
        connected: true,
        sessionId: stored.sessionId,
        user: stored.user || 'unknown',
        warehouse: stored.warehouse,
        database: stored.database,
        schema: stored.schema,
        role: stored.role
      };
      setStatus(assumedSessionStatus);
      setLoading(false);
      testingInProgressRef.current = false;
      connectionLog.info('Keeping session valid despite backend unreachable', { database: stored.database });
      return assumedSessionStatus;
    }
  }, [getStoredSession, status]);

  // Store ref for useEffect
  testConnectionRef.current = testConnection;

  // Disconnect
  const disconnect = useCallback(async () => {
    connectionLog.info('disconnect() called');
    const stored = getStoredSession();
    if (stored?.sessionId) {
      try {
        const endTimer = connectionLog.time('Backend disconnect');
        await fetchWithTimeout(
          `${API_URL}/api/disconnect`,
          {
            method: 'POST',
            headers: { 'X-Session-ID': stored.sessionId }
          },
          5000
        );
        endTimer();
        connectionLog.info('Disconnected from backend');
      } catch (err) {
        if (err.name !== 'AbortError') {
          connectionLog.warn('Disconnect request failed', { message: err.message });
        }
      }
    }
    sessionStorage.removeItem(SESSION_KEY);
    setStatus({ connected: false });
    connectionLog.info('Session cleared');
  }, [getStoredSession]);

  // Load session on mount
  useEffect(() => {
    connectionLog.debug('useConnection mounted - checking existing session');
    testConnectionRef.current?.();
  }, []);

  return { status, testConnection, disconnect, loading, error };
}

// =============================================================================
// Query Execution Hook
// =============================================================================

export function useQuery() {
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const executeQuery = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    
    queryLog.info('executeQuery() called', {
      hasSession: !!sessionId,
      sqlPreview: sql.substring(0, 100) + (sql.length > 100 ? '...' : ''),
      database: options.database,
      schema: options.schema
    });

    if (!sessionId) {
      queryLog.warn('executeQuery() - no active session, aborting');
      setError('Not connected. Please connect to Snowflake first.');
      return null;
    }

    setLoading(true);
    setError(null);

    const endTimer = queryLog.time('Query execution');

    try {
      const timeoutMs = (options.timeout || 60) * 1000 + 5000;
      
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/execute`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            sql,
            database: options.database,
            schema_name: options.schema,
            warehouse: options.warehouse,
            timeout: options.timeout || 60,
            limit: options.limit || 10000
          })
        },
        timeoutMs
      );

      queryLog.debug('executeQuery() - response meta', {
        status: response.status,
        ok: response.ok
      });

      // Handle session expiration
      if (response.status === 401) {
        queryLog.warn('Session expired (401) - clearing session');
        sessionStorage.removeItem(SESSION_KEY);
        setError('Session expired. Please reconnect.');
        setResults(null);
        return null;
      }

      const data = await response.json();
      queryLog.debug('executeQuery() - response body', {
        status: data.status,
        queryId: data.query_id,
        rowCount: data.row_count
      });

      if (data.status === 'SUCCESS') {
        // Fetch results
        const resultsRes = await fetchWithTimeout(
          `${API_URL}/api/query/${data.query_id}/results`,
          { headers: { 'X-Session-ID': sessionId } },
          30000
        );
        
        if (!resultsRes.ok) {
          queryLog.warn('Results fetch failed, using execute response', { status: resultsRes.status });
          const result = {
            columns: [],
            rows: [],
            rowCount: data.row_count || 0,
            executionTime: data.execution_time_ms,
            warning: `Results fetch failed: ${resultsRes.status}`
          };
          setResults(result);
          endTimer({ rowCount: result.rowCount, status: 'partial' });
          return result;
        }
        
        const resultsData = await resultsRes.json();

        const result = {
          columns: resultsData.columns || [],
          rows: resultsData.rows || [],
          rowCount: resultsData.total_rows ?? resultsData.rows?.length ?? data.row_count ?? 0,
          executionTime: data.execution_time_ms
        };
        setResults(result);
        
        const durationMs = endTimer({ rowCount: result.rowCount, status: 'success' });
        queryLog.info('executeQuery() - success', {
          rowCount: result.rowCount,
          columnCount: result.columns.length,
          executionTimeMs: result.executionTime,
          totalDurationMs: durationMs
        });
        
        return result;
      } else {
        queryLog.error('executeQuery() - backend returned error', { message: data.message });
        setError(data.message || 'Query failed');
        endTimer({ status: 'error' });
        return { success: false, error: data.message };
      }
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Query timed out. Try a shorter query or increase the timeout.'
        : (err.message || 'Query failed');
      queryLog.error('executeQuery() - exception', {
        message: err.message,
        isTimeout: err.name === 'AbortError'
      });
      setError(errorMsg);
      endTimer({ status: 'exception' });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    queryLog.debug('clearResults() called');
    setResults(null);
    setError(null);
  }, []);

  return { results, loading, error, executeQuery, clearResults };
}

// =============================================================================
// Preflight Check Hook
// =============================================================================

export function usePreflight() {
  const [preflightResult, setPreflightResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const runPreflight = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    
    preflightLog.info('runPreflight() called', {
      hasSession: !!sessionId,
      sqlPreview: sql.substring(0, 80) + (sql.length > 80 ? '...' : '')
    });

    if (!sessionId) {
      preflightLog.warn('runPreflight() - no session');
      return { valid: false, message: 'Not connected' };
    }

    setLoading(true);
    setPreflightResult(null);

    const endTimer = preflightLog.time('Preflight check');

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/preflight`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            sql,
            database: options.database,
            schema_name: options.schema
          })
        },
        15000
      );

      if (response.status === 401) {
        preflightLog.warn('Session expired during preflight');
        sessionStorage.removeItem(SESSION_KEY);
        return { valid: false, message: 'Session expired' };
      }

      const data = await response.json();
      setPreflightResult(data);
      
      endTimer({ valid: data.valid, issueCount: data.issues?.length || 0 });
      preflightLog.info('runPreflight() - complete', { valid: data.valid });
      
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Preflight check timed out' 
        : err.message;
      preflightLog.error('runPreflight() - failed', { message: errorMsg });
      const error = { valid: false, message: errorMsg, issues: [errorMsg] };
      setPreflightResult(error);
      endTimer({ valid: false, error: true });
      return error;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearPreflight = useCallback(() => {
    preflightLog.debug('clearPreflight() called');
    setPreflightResult(null);
  }, []);

  return { preflightResult, loading, runPreflight, clearPreflight };
}

// =============================================================================
// Query History Hook
// =============================================================================

export function useQueryHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchHistory = useCallback(async () => {
    const sessionId = getSessionId();
    if (!sessionId) {
      historyLog.warn('fetchHistory() - no session ID');
      return;
    }

    historyLog.info('fetchHistory() called');
    setLoading(true);
    
    const endTimer = historyLog.time('Fetch history');
    
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/query/history?limit=50`,
        { headers: { 'X-Session-ID': sessionId } },
        10000
      );
      const data = await res.json();
      setHistory(data.items || []);
      endTimer({ itemCount: data.items?.length || 0 });
      historyLog.info('fetchHistory() - success', { itemCount: data.items?.length || 0 });
    } catch (err) {
      if (err.name !== 'AbortError') {
        historyLog.error('fetchHistory() - failed', { message: err.message });
      }
      endTimer({ error: true });
    } finally {
      setLoading(false);
    }
  }, []);

  return { history, fetchHistory, loading };
}

// =============================================================================
// Metadata Hook
// =============================================================================

export function useMetadata() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchDatabases = useCallback(async (refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      metadataLog.warn('fetchDatabases() - no session');
      return [];
    }

    metadataLog.info('fetchDatabases() called', { refresh });
    setLoading(true);
    
    const endTimer = metadataLog.time('Fetch databases');
    
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/databases?refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000
      );
      const data = await res.json();
      endTimer({ count: Array.isArray(data) ? data.length : 0 });
      metadataLog.debug('fetchDatabases() - success', { count: Array.isArray(data) ? data.length : 0 });
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      metadataLog.error('fetchDatabases() - failed', { message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchSchemas = useCallback(async (database, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      metadataLog.warn('fetchSchemas() - no session');
      return [];
    }

    metadataLog.info('fetchSchemas() called', { database, refresh });
    setLoading(true);
    
    const endTimer = metadataLog.time(`Fetch schemas for ${database}`);
    
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/schemas?database=${encodeURIComponent(database)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000
      );
      const data = await res.json();
      endTimer({ count: Array.isArray(data) ? data.length : 0 });
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      metadataLog.error('fetchSchemas() - failed', { database, message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchTables = useCallback(async (database, schema, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      metadataLog.warn('fetchTables() - no session');
      return [];
    }

    metadataLog.info('fetchTables() called', { database, schema, refresh });
    setLoading(true);
    
    const endTimer = metadataLog.time(`Fetch tables for ${database}.${schema}`);
    
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/tables?database=${encodeURIComponent(database)}&schema=${encodeURIComponent(schema)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        20000
      );
      const data = await res.json();
      endTimer({ count: Array.isArray(data) ? data.length : 0 });
      metadataLog.debug('fetchTables() - success', { count: Array.isArray(data) ? data.length : 0 });
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      metadataLog.error('fetchTables() - failed', { database, schema, message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchColumns = useCallback(async (database, schema, table, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      metadataLog.warn('fetchColumns() - no session');
      return [];
    }

    metadataLog.debug('fetchColumns() called', { database, schema, table, refresh });
    setLoading(true);
    
    const endTimer = metadataLog.time(`Fetch columns for ${database}.${schema}.${table}`);
    
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/columns?database=${encodeURIComponent(database)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000
      );
      const data = await res.json();
      endTimer({ count: Array.isArray(data) ? data.length : 0 });
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      metadataLog.error('fetchColumns() - failed', { table, message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshCache = useCallback(async () => {
    metadataLog.info('refreshCache() called');
    setLoading(true);
    try {
      await fetchDatabases(true);
      metadataLog.info('refreshCache() - complete');
    } finally {
      setLoading(false);
    }
  }, [fetchDatabases]);

  return {
    loading,
    error,
    fetchDatabases,
    fetchSchemas,
    fetchTables,
    fetchColumns,
    refreshCache
  };
}

// =============================================================================
// Batch Validation Hook
// =============================================================================

export function useBatchValidation() {
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const validateBatch = useCallback(async (queries, options = {}) => {
    const sessionId = getSessionId();
    
    batchLog.info('validateBatch() called', {
      hasSession: !!sessionId,
      queryCount: queries.length,
      database: options.database
    });

    if (!sessionId) {
      batchLog.warn('validateBatch() - no session');
      setError('Not connected');
      return null;
    }

    setLoading(true);
    setError(null);

    const endTimer = batchLog.time('Batch validation');

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/validate-batch`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            queries,
            database: options.database,
            schema_name: options.schema,
            include_samples: options.includeSamples ?? true,
            sample_limit: options.sampleLimit ?? 3
          })
        },
        60000
      );

      if (response.status === 401) {
        batchLog.warn('Session expired during batch validation');
        sessionStorage.removeItem(SESSION_KEY);
        setError('Session expired');
        endTimer({ error: 'session_expired' });
        return null;
      }

      const data = await response.json();
      setResults(data);
      
      const validCount = data.results?.filter(r => r.valid).length || 0;
      endTimer({ validCount, totalCount: queries.length });
      batchLog.info('validateBatch() - complete', { validCount, totalCount: queries.length });
      
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Batch validation timed out' 
        : err.message;
      batchLog.error('validateBatch() - failed', { message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    batchLog.debug('clearResults() called');
    setResults(null);
    setError(null);
  }, []);

  return { results, loading, error, validateBatch, clearResults };
}

// =============================================================================
// Query Explanation Hook
// =============================================================================

export function useQueryExplanation() {
  const [explanation, setExplanation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const explainQuery = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    
    explainLog.info('explainQuery() called', {
      hasSession: !!sessionId,
      sqlPreview: sql.substring(0, 80) + (sql.length > 80 ? '...' : '')
    });
    
    setLoading(true);
    setError(null);

    const endTimer = explainLog.time('Query explanation');

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/explain`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(sessionId && { 'X-Session-ID': sessionId })
          },
          body: JSON.stringify({
            sql,
            include_execution: options.includeExecution ?? !!sessionId
          })
        },
        30000
      );

      if (response.status === 401) {
        explainLog.warn('Session expired during explain');
        sessionStorage.removeItem(SESSION_KEY);
      }

      const data = await response.json();
      setExplanation(data);
      
      endTimer({ hasExplanation: !!data.explanation });
      explainLog.info('explainQuery() - complete');
      
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Query explanation timed out' 
        : err.message;
      explainLog.error('explainQuery() - failed', { message: errorMsg });
      setError(errorMsg);
      endTimer({ error: true });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearExplanation = useCallback(() => {
    explainLog.debug('clearExplanation() called');
    setExplanation(null);
    setError(null);
  }, []);

  return { explanation, loading, error, explainQuery, clearExplanation };
}

export default { useConnection, useQuery, useQueryHistory, useMetadata, usePreflight, useBatchValidation, useQueryExplanation };
