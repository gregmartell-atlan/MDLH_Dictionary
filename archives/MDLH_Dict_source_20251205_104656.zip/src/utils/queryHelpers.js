/**
 * Query Helper Utilities
 * 
 * Functions for query validation, pre-validation, and smart query generation.
 */

import { extractTableFromQuery, fixQueryForAvailableTables } from './tableDiscovery';

/**
 * Pre-validate all queries and return a validation map
 * @param {Object} allQueries - Object with category keys and query arrays
 * @param {Set<string>} discoveredTables - Set of discovered table names
 * @param {string} database - Database name
 * @param {string} schema - Schema name
 * @returns {Map} Map of queryId -> validation result
 */
export function preValidateAllQueries(allQueries, discoveredTables, database, schema) {
  const validationMap = new Map();
  
  Object.entries(allQueries).forEach(([category, queries]) => {
    queries.forEach((q, index) => {
      const queryId = `${category}-${index}`;
      const tableName = extractTableFromQuery(q.query);
      
      if (!tableName) {
        validationMap.set(queryId, { valid: null, tableName: null });
        return;
      }
      
      const tableExists = discoveredTables.has(tableName.toUpperCase());
      
      if (tableExists) {
        validationMap.set(queryId, { 
          valid: true, 
          tableName,
          originalQuery: q.query
        });
      } else {
        // Try to fix the query
        const fixed = fixQueryForAvailableTables(q.query, discoveredTables, database, schema);
        
        if (fixed.fixed) {
          validationMap.set(queryId, {
            valid: true,
            tableName: fixed.changes[0]?.to,
            originalQuery: q.query,
            fixedQuery: fixed.sql,
            changes: fixed.changes,
            autoFixed: true
          });
        } else {
          validationMap.set(queryId, {
            valid: false,
            tableName,
            originalQuery: q.query,
            error: `Table ${tableName} not found in ${database}.${schema}`
          });
        }
      }
    });
  });
  
  return validationMap;
}

/**
 * Sort queries with validated ones first, unavailable last
 * @param {Array} queries - Array of query objects
 * @param {Function} getAvailability - Function to check table availability
 * @returns {Array} Sorted queries
 */
export function sortQueriesByAvailability(queries, getAvailability) {
  return [...queries].sort((a, b) => {
    const availA = getAvailability(a.query);
    const availB = getAvailability(b.query);
    
    // Validated first (true), then unknown (null), then unavailable (false)
    if (availA === true && availB !== true) return -1;
    if (availB === true && availA !== true) return 1;
    if (availA === false && availB !== false) return 1;
    if (availB === false && availA !== false) return -1;
    return 0;
  });
}

/**
 * Generate query suggestions based on entity data and available tables
 * @param {string} entityType - Entity type name
 * @param {string} tableName - Table name
 * @param {Set<string>} discoveredTables - Available tables
 * @param {string} database - Database name
 * @param {string} schema - Schema name
 * @returns {Array<{title: string, query: string}>}
 */
export function generateQuerySuggestions(entityType, tableName, discoveredTables, database, schema) {
  const suggestions = [];
  
  if (!tableName || tableName === '(abstract)' || !discoveredTables.has(tableName.toUpperCase())) {
    return suggestions;
  }
  
  const fullTableRef = `${database}.${schema}.${tableName}`;
  
  // Basic count query
  suggestions.push({
    title: `Count ${entityType} records`,
    query: `SELECT COUNT(*) AS total_count FROM ${fullTableRef};`
  });
  
  // Sample rows
  suggestions.push({
    title: `Sample ${entityType} data`,
    query: `SELECT * FROM ${fullTableRef} LIMIT 10;`
  });
  
  // Recent records (if table has timestamp columns)
  suggestions.push({
    title: `Recently updated ${entityType}`,
    query: `SELECT NAME, GUID, TO_TIMESTAMP(UPDATETIME/1000) AS updated_at
FROM ${fullTableRef}
WHERE UPDATETIME IS NOT NULL
ORDER BY UPDATETIME DESC
LIMIT 20;`
  });
  
  return suggestions;
}

/**
 * Parse SQL to extract all table references
 * @param {string} sql - SQL query
 * @returns {Array<string>} Array of table names
 */
export function extractAllTablesFromQuery(sql) {
  if (!sql) return [];
  
  const tables = [];
  const patterns = [
    /FROM\s+(?:[\w.]+\.)?(\w+)/gi,
    /JOIN\s+(?:[\w.]+\.)?(\w+)/gi,
    /INTO\s+(?:[\w.]+\.)?(\w+)/gi,
    /UPDATE\s+(?:[\w.]+\.)?(\w+)/gi,
  ];
  
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(sql)) !== null) {
      const tableName = match[1].toUpperCase();
      if (!tables.includes(tableName)) {
        tables.push(tableName);
      }
    }
  }
  
  return tables;
}

/**
 * Check if a query is read-only (SELECT/SHOW/DESCRIBE)
 * @param {string} sql - SQL query
 * @returns {boolean}
 */
export function isReadOnlyQuery(sql) {
  if (!sql) return true;
  
  const trimmed = sql.trim().toUpperCase();
  const readOnlyPrefixes = ['SELECT', 'SHOW', 'DESCRIBE', 'DESC', 'EXPLAIN', 'WITH'];
  
  return readOnlyPrefixes.some(prefix => trimmed.startsWith(prefix));
}

/**
 * Add LIMIT clause if not present (for safety)
 * @param {string} sql - SQL query
 * @param {number} limit - Default limit (default: 1000)
 * @returns {string}
 */
export function ensureQueryLimit(sql, limit = 1000) {
  if (!sql) return sql;
  
  const trimmed = sql.trim();
  
  // Only add limit to SELECT statements without existing LIMIT
  if (!trimmed.toUpperCase().startsWith('SELECT')) return sql;
  if (/LIMIT\s+\d+/i.test(trimmed)) return sql;
  
  // Remove trailing semicolon, add LIMIT, add semicolon back
  const withoutSemicolon = trimmed.replace(/;\s*$/, '');
  return `${withoutSemicolon} LIMIT ${limit};`;
}

/**
 * Format SQL for display (basic formatting)
 * @param {string} sql - SQL query
 * @returns {string}
 */
export function formatSQL(sql) {
  if (!sql) return '';
  
  // Basic keyword capitalization
  const keywords = ['SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 
    'ON', 'AND', 'OR', 'GROUP', 'BY', 'ORDER', 'LIMIT', 'HAVING', 'UNION', 'ALL',
    'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'ALTER', 'DROP',
    'TABLE', 'VIEW', 'INDEX', 'AS', 'DISTINCT', 'COUNT', 'SUM', 'AVG', 'MIN', 'MAX'];
  
  let formatted = sql;
  keywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    formatted = formatted.replace(regex, keyword);
  });
  
  return formatted;
}

export default {
  preValidateAllQueries,
  sortQueriesByAvailability,
  generateQuerySuggestions,
  extractAllTablesFromQuery,
  isReadOnlyQuery,
  ensureQueryLimit,
  formatSQL,
};

