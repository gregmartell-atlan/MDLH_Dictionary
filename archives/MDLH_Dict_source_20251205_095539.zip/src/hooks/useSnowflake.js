/**
 * Snowflake hooks - React hooks for managing Snowflake operations
 * 
 * Updated to use session-based backend with X-Session-ID headers.
 * Includes fetch timeout support and improved error handling.
 */

import { useState, useCallback, useEffect, useRef } from 'react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const SESSION_KEY = 'snowflake_session';
const DEFAULT_TIMEOUT_MS = 30000; // 30 seconds default timeout

// =============================================================================
// Shared Helpers (DRY)
// =============================================================================

/**
 * Get session ID from sessionStorage
 * @returns {string|null} Session ID or null
 */
function getSessionId() {
  const stored = sessionStorage.getItem(SESSION_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      console.log('[useSnowflake] getSessionId():', {
        hasSession: !!parsed.sessionId,
        sessionPrefix: parsed.sessionId?.substring(0, 8),
        database: parsed.database,
        schema: parsed.schema
      });
      return parsed.sessionId;
    } catch (e) {
      console.error('[useSnowflake] getSessionId() parse error:', e);
      return null;
    }
  }
  console.log('[useSnowflake] getSessionId(): No session in storage');
  return null;
}

/**
 * Fetch with timeout wrapper - prevents hanging requests
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options
 * @param {number} timeoutMs - Timeout in milliseconds (default: 30000)
 * @returns {Promise<Response>}
 */
async function fetchWithTimeout(url, options = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, { 
      ...options, 
      signal: controller.signal 
    });
    return response;
  } finally {
    clearTimeout(id);
  }
}

// =============================================================================
// Session Management Hook
// =============================================================================

export function useConnection() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const testConnectionRef = useRef(null);

  // Get session from storage
  const getStoredSession = useCallback(() => {
    const storedRaw = sessionStorage.getItem(SESSION_KEY);
    console.log('[useConnection] getStoredSession() - raw value:', storedRaw ? `${storedRaw.substring(0, 50)}...` : 'NULL');
    if (storedRaw) {
      try {
        const parsed = JSON.parse(storedRaw);
        console.log('[useConnection] getStoredSession() - parsed:', JSON.stringify({
          hasSessionId: !!parsed.sessionId,
          sessionIdPrefix: parsed.sessionId?.substring(0, 8) || 'N/A',
          keys: Object.keys(parsed)
        }));
        return parsed;
      } catch (e) {
        console.error('[useConnection] getStoredSession() - parse error:', e);
        sessionStorage.removeItem(SESSION_KEY);
      }
    }
    return null;
  }, []);

  // Check if session is valid
  const testConnection = useCallback(async () => {
    console.log('[useConnection] testConnection() called');
    setLoading(true);
    setError(null);

    const stored = getStoredSession();
    console.log('[useConnection] testConnection() - stored session:', JSON.stringify({
      hasSession: !!stored,
      hasSessionId: !!stored?.sessionId,
      sessionIdPrefix: stored?.sessionId?.substring(0, 8) || 'N/A',
      database: stored?.database || 'N/A',
      keys: stored ? Object.keys(stored) : []
    }));
    
    if (stored?.sessionId) {
      try {
        console.log('[useConnection] Checking session status with backend...');
        const res = await fetchWithTimeout(
          `${API_URL}/api/session/status`,
          { headers: { 'X-Session-ID': stored.sessionId } },
          10000 // 10s timeout for status check
        );
        const data = await res.json();
        console.log('[useConnection] Session status response:', {
          valid: data.valid,
          user: data.user,
          database: data.database
        });
        
        if (data.valid) {
          const sessionStatus = {
            connected: true,
            sessionId: stored.sessionId,
            user: data.user,
            warehouse: data.warehouse,
            database: data.database,
            schema: data.schema_name,
            role: data.role
          };
          setStatus(sessionStatus);
          setLoading(false);
          console.log('[useConnection] Session VALID - connected');
          return sessionStatus;
        } else {
          console.log('[useConnection] Session INVALID - removing from storage');
          sessionStorage.removeItem(SESSION_KEY);
        }
      } catch (err) {
        // Only log non-abort errors
        if (err.name !== 'AbortError') {
          console.warn('[useConnection] Session check failed:', err.message);
        }
        console.log('[useConnection] Session check error - removing from storage');
        sessionStorage.removeItem(SESSION_KEY);
      }
    }

    console.log('[useConnection] No valid session - setting connected=false');
    setStatus({ connected: false });
    setLoading(false);
    return { connected: false };
  }, [getStoredSession]);

  // Store ref for useEffect
  testConnectionRef.current = testConnection;

  // Disconnect
  const disconnect = useCallback(async () => {
    const stored = getStoredSession();
    if (stored?.sessionId) {
      try {
        await fetchWithTimeout(
          `${API_URL}/api/disconnect`,
          {
            method: 'POST',
            headers: { 'X-Session-ID': stored.sessionId }
          },
          5000 // 5s timeout for disconnect
        );
      } catch (err) {
        // Log but don't throw - we're disconnecting anyway
        if (err.name !== 'AbortError') {
          console.warn('[useConnection] Disconnect request failed:', err.message);
        }
      }
    }
    sessionStorage.removeItem(SESSION_KEY);
    setStatus({ connected: false });
  }, [getStoredSession]);

  // Load session on mount
  useEffect(() => {
    // Use ref to avoid stale closure
    testConnectionRef.current?.();
  }, []);

  return { status, testConnection, disconnect, loading, error };
}

// =============================================================================
// Query Execution Hook
// =============================================================================

export function useQuery() {
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const executeQuery = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      setError('Not connected. Please connect to Snowflake first.');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const timeoutMs = (options.timeout || 60) * 1000 + 5000; // Query timeout + 5s buffer
      
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/execute`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            sql,
            database: options.database,
            schema_name: options.schema,
            warehouse: options.warehouse,
            timeout: options.timeout || 60,
            limit: options.limit || 10000
          })
        },
        timeoutMs
      );

      // Handle session expiration
      if (response.status === 401) {
        sessionStorage.removeItem(SESSION_KEY);
        setError('Session expired. Please reconnect.');
        setResults(null);
        return null;
      }

      const data = await response.json();

      if (data.status === 'SUCCESS') {
        // Fetch results
        const resultsRes = await fetchWithTimeout(
          `${API_URL}/api/query/${data.query_id}/results`,
          { headers: { 'X-Session-ID': sessionId } },
          30000 // 30s timeout for results fetch
        );
        
        // Check for errors in results fetch
        if (!resultsRes.ok) {
          // If results fetch failed, still show what we know from the execute response
          console.warn(`[Query] Results fetch failed (${resultsRes.status}), using execute response`);
          const result = {
            columns: [],
            rows: [],
            rowCount: data.row_count || 0,
            executionTime: data.execution_time_ms,
            warning: `Results fetch failed: ${resultsRes.status}`
          };
          setResults(result);
          return result;
        }
        
        const resultsData = await resultsRes.json();

        const result = {
          columns: resultsData.columns || [],
          rows: resultsData.rows || [],
          rowCount: resultsData.total_rows ?? resultsData.rows?.length ?? data.row_count ?? 0,
          executionTime: data.execution_time_ms
        };
        setResults(result);
        return result;
      } else {
        setError(data.message || 'Query failed');
        return { success: false, error: data.message };
      }
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Query timed out. Try a shorter query or increase the timeout.'
        : (err.message || 'Query failed');
      setError(errorMsg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults(null);
    setError(null);
  }, []);

  return { results, loading, error, executeQuery, clearResults };
}

// =============================================================================
// Preflight Check Hook
// =============================================================================

export function usePreflight() {
  const [preflightResult, setPreflightResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const runPreflight = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      return { valid: false, message: 'Not connected' };
    }

    setLoading(true);
    setPreflightResult(null);

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/preflight`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            sql,
            database: options.database,
            schema_name: options.schema
          })
        },
        15000 // 15s timeout for preflight
      );

      if (response.status === 401) {
        sessionStorage.removeItem(SESSION_KEY);
        return { valid: false, message: 'Session expired' };
      }

      const data = await response.json();
      setPreflightResult(data);
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Preflight check timed out' 
        : err.message;
      const error = { valid: false, message: errorMsg, issues: [errorMsg] };
      setPreflightResult(error);
      return error;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearPreflight = useCallback(() => {
    setPreflightResult(null);
  }, []);

  return { preflightResult, loading, runPreflight, clearPreflight };
}

// =============================================================================
// Query History Hook
// =============================================================================

export function useQueryHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchHistory = useCallback(async () => {
    const sessionId = getSessionId();
    if (!sessionId) {
      console.warn('[useQueryHistory] No session ID - cannot fetch history');
      return;
    }

    setLoading(true);
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/query/history?limit=50`,
        { headers: { 'X-Session-ID': sessionId } },
        10000 // 10s timeout for history
      );
      const data = await res.json();
      setHistory(data.items || []);
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.error('Failed to fetch history:', err);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  return { history, fetchHistory, loading };
}

// =============================================================================
// Metadata Hook
// =============================================================================

export function useMetadata() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchDatabases = useCallback(async (refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) return [];

    setLoading(true);
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/databases?refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000 // 15s timeout
      );
      return await res.json();
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      setError(errorMsg);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchSchemas = useCallback(async (database, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) return [];

    setLoading(true);
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/schemas?database=${encodeURIComponent(database)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000
      );
      return await res.json();
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      setError(errorMsg);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchTables = useCallback(async (database, schema, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) return [];

    setLoading(true);
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/tables?database=${encodeURIComponent(database)}&schema=${encodeURIComponent(schema)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        20000 // 20s timeout for tables
      );
      return await res.json();
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      setError(errorMsg);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchColumns = useCallback(async (database, schema, table, refresh = false) => {
    const sessionId = getSessionId();
    if (!sessionId) return [];

    setLoading(true);
    try {
      const res = await fetchWithTimeout(
        `${API_URL}/api/metadata/columns?database=${encodeURIComponent(database)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}&refresh=${refresh}`,
        { headers: { 'X-Session-ID': sessionId } },
        15000
      );
      return await res.json();
    } catch (err) {
      const errorMsg = err.name === 'AbortError' ? 'Request timed out' : err.message;
      setError(errorMsg);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  // Refresh cache by forcing a refetch
  const refreshCache = useCallback(async () => {
    // Simply force a refresh on databases
    setLoading(true);
    try {
      await fetchDatabases(true);
    } finally {
      setLoading(false);
    }
  }, [fetchDatabases]);

  return {
    loading,
    error,
    fetchDatabases,
    fetchSchemas,
    fetchTables,
    fetchColumns,
    refreshCache
  };
}

// =============================================================================
// Batch Validation Hook
// =============================================================================

export function useBatchValidation() {
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const validateBatch = useCallback(async (queries, options = {}) => {
    const sessionId = getSessionId();
    if (!sessionId) {
      setError('Not connected');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/validate-batch`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sessionId
          },
          body: JSON.stringify({
            queries,
            database: options.database,
            schema_name: options.schema,
            include_samples: options.includeSamples ?? true,
            sample_limit: options.sampleLimit ?? 3
          })
        },
        60000 // 60s timeout for batch validation
      );

      if (response.status === 401) {
        sessionStorage.removeItem(SESSION_KEY);
        setError('Session expired');
        return null;
      }

      const data = await response.json();
      setResults(data);
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Batch validation timed out' 
        : err.message;
      setError(errorMsg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults(null);
    setError(null);
  }, []);

  return { results, loading, error, validateBatch, clearResults };
}

// =============================================================================
// Query Explanation Hook
// =============================================================================

export function useQueryExplanation() {
  const [explanation, setExplanation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const explainQuery = useCallback(async (sql, options = {}) => {
    const sessionId = getSessionId();
    
    setLoading(true);
    setError(null);

    try {
      const response = await fetchWithTimeout(
        `${API_URL}/api/query/explain`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(sessionId && { 'X-Session-ID': sessionId })
          },
          body: JSON.stringify({
            sql,
            include_execution: options.includeExecution ?? !!sessionId
          })
        },
        30000 // 30s timeout for explain
      );

      if (response.status === 401) {
        sessionStorage.removeItem(SESSION_KEY);
      }

      const data = await response.json();
      setExplanation(data);
      return data;
    } catch (err) {
      const errorMsg = err.name === 'AbortError' 
        ? 'Query explanation timed out' 
        : err.message;
      setError(errorMsg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearExplanation = useCallback(() => {
    setExplanation(null);
    setError(null);
  }, []);

  return { explanation, loading, error, explainQuery, clearExplanation };
}

export default { useConnection, useQuery, useQueryHistory, useMetadata, usePreflight, useBatchValidation, useQueryExplanation };
